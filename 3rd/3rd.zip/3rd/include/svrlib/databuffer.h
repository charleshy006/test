/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_DATA_BUFFER_H__
#define __NET_DATA_BUFFER_H__

#include "Log4cxxHelp.h"
#define MAX_BUFFER_SIZE 65535

namespace net
{

class DataBuffer {

public:
    /*
     * 构造函数
     */
    DataBuffer() {
        m_pend = m_pfree = m_pdata = m_pstart = NULL;
    }

    /*
     * 析构函数
     */
    ~DataBuffer() {
        destroy();
    }

    /**
     * 回收内存
     */
    void destroy() {
        if (m_pstart) {
            free(m_pstart);
            m_pend = m_pfree = m_pdata = m_pstart = NULL;
        }
    }

    char *getData() {
        return (char*)m_pdata;
    }

    int getDataLen() {
        return static_cast<int32_t>(m_pfree - m_pdata);
    }

    char *getFree() {
        return (char*)m_pfree;
    }

    int getFreeLen() {
        return static_cast<int32_t>(m_pend - m_pfree);
    }

    void drainData(int len) {
        m_pdata += len;

        if (m_pdata >= m_pfree) {
            clear();
        }
    }

    void pourData(int len) {
        assert(m_pend - m_pfree >= len);
        m_pfree += len;
    }

    void stripData(int len) {
        assert(m_pfree - m_pdata >= len);
        m_pfree -= len;
    }

    void clear() {
        m_pdata = m_pfree = m_pstart;
    }

    void shrink() {
        if (m_pstart == NULL) {
            return;
        }
        if ((m_pend - m_pstart) <= MAX_BUFFER_SIZE || (m_pfree - m_pdata) > MAX_BUFFER_SIZE) {
            return;
        }
		return;
        int dlen = static_cast<int32_t>(m_pfree - m_pdata);
        if (dlen < 0) dlen = 0;

        unsigned char *newbuf = (unsigned char*)malloc(MAX_BUFFER_SIZE);
        assert(newbuf != NULL);

        if (dlen > 0) {
            memcpy(newbuf, m_pdata, dlen);
        }
        free(m_pstart);

        m_pdata = m_pstart = newbuf;
        m_pfree = m_pstart + dlen;
        m_pend = m_pstart + MAX_BUFFER_SIZE;
#ifdef _HDZ_DEBUG
		Athena::logger->trace("底层数据进行了收缩操作!");
#endif
        return;
    }


    /*
     * 写函数
     */
    void writeInt8(uint8_t n) {
        expand(1);
        *m_pfree++ = (unsigned char)n;
    }

    void writeInt16(uint16_t n) {
        expand(2);
        m_pfree[1] = (unsigned char)n;
        n = static_cast<uint16_t>(n >> 8);
        m_pfree[0] = (unsigned char)n;
        m_pfree += 2;
    }

    /*
     * 写出整型
     */
    void writeInt32(uint32_t n) {
        expand(4);
        m_pfree[3] = (unsigned char)n;
        n >>= 8;
        m_pfree[2] = (unsigned char)n;
        n >>= 8;
        m_pfree[1] = (unsigned char)n;
        n >>= 8;
        m_pfree[0] = (unsigned char)n;
        m_pfree += 4;
    }

    void writeInt64(uint64_t n) {
        expand(8);
        m_pfree[7] = (unsigned char)n;
        n >>= 8;
        m_pfree[6] = (unsigned char)n;
        n >>= 8;
        m_pfree[5] = (unsigned char)n;
        n >>= 8;
        m_pfree[4] = (unsigned char)n;
        n >>= 8;
        m_pfree[3] = (unsigned char)n;
        n >>= 8;
        m_pfree[2] = (unsigned char)n;
        n >>= 8;
        m_pfree[1] = (unsigned char)n;
        n >>= 8;
        m_pfree[0] = (unsigned char)n;
        m_pfree += 8;
    }

    void writeBytes(const void *src, int len) {
        expand(len);
        memcpy(m_pfree, src, len);
        m_pfree += len;
    }

    /*
     * 在某一位置写一整型
     */
    void fillInt8(unsigned char *dst, uint8_t n) {
        *dst = n;
    }

    void fillInt16(unsigned char *dst, uint16_t n) {
        dst[1] = (unsigned char)n;
        n = static_cast<uint16_t>(n >> 8);
        dst[0] = (unsigned char)n;
    }

    void fillInt32(unsigned char *dst, uint32_t n) {
        dst[3] = (unsigned char)n;
        n >>= 8;
        dst[2] = (unsigned char)n;
        n >>= 8;
        dst[1] = (unsigned char)n;
        n >>= 8;
        dst[0] = (unsigned char)n;
    }
   
    void fillInt64(unsigned char *dst, uint64_t n) {
        dst[7] = (unsigned char)n;
        n >>= 8;
        dst[6] = (unsigned char)n;
        n >>= 8;
        dst[5] = (unsigned char)n;
        n >>= 8;
        dst[4] = (unsigned char)n;
        n >>= 8;
        dst[3] = (unsigned char)n;
        n >>= 8;
        dst[2] = (unsigned char)n;
        n >>= 8;
        dst[1] = (unsigned char)n;
        n >>= 8;
        dst[0] = (unsigned char)n;
    }

    /*
     * 写字符串
     */
    void writeString(const char *str) {
        int len = (str ? static_cast<int32_t>(strlen(str)) : 0);
        if (len>0) len ++;
        expand(static_cast<int32_t>(len+sizeof(uint32_t)));
        writeInt32(len);
        if (len>0) {
            memcpy(m_pfree, str, len);
            m_pfree += (len);
        }
    }

    void writeString(const std::string& str) {
        writeString(str.c_str());
    }

    /**
     *写一个int列表
     */
    void writeVector(const std::vector<int32_t>& v) {
        const uint32_t iLen = static_cast<uint32_t>(v.size());
        writeInt32(iLen);
        for (uint32_t i = 0; i < iLen; ++i) {
             writeInt32(v[i]); 
        }
    }

    void writeVector(const std::vector<uint32_t>& v) {
        const uint32_t iLen = static_cast<uint32_t>(v.size());
        writeInt32(iLen);
        for (uint32_t i = 0; i < iLen; ++i) {
             writeInt32(v[i]);
        } 
    }

    void writeVector(const std::vector<int64_t>& v) {
        const uint32_t iLen = static_cast<uint32_t>(v.size());
        writeInt32(iLen);
        for (uint32_t i = 0; i < iLen; ++i) {
             writeInt64(v[i]);
        }
    }

    void writeVector(const std::vector<uint64_t>& v) {
        const uint32_t iLen = static_cast<uint32_t>(v.size());
        writeInt32(iLen);
        for (uint32_t i = 0; i < iLen; ++i) {
             writeInt64(v[i]);
        }
    }

    /*
     * 读函数
     */
    uint8_t readInt8() {
        return (*m_pdata++);
    }

    uint16_t readInt16() {
        uint16_t n = m_pdata[0];
        n = static_cast<uint16_t>(n << 8);
        n = static_cast<uint16_t>(n | m_pdata[1]);
        m_pdata += 2;
        return n;
    }

    uint32_t readInt32() {
        uint32_t n = m_pdata[0];
        n <<= 8;
        n |= m_pdata[1];
        n <<= 8;
        n |= m_pdata[2];
        n <<= 8;
        n |= m_pdata[3];
        m_pdata += 4;
        assert(m_pfree>=m_pdata);
        return n;
    }

    uint64_t readInt64() {
        uint64_t n = m_pdata[0];
        n <<= 8;
        n |= m_pdata[1];
        n <<= 8;
        n |= m_pdata[2];
        n <<= 8;
        n |= m_pdata[3];
        n <<= 8;
        n |= m_pdata[4];
        n <<= 8;
        n |= m_pdata[5];
        n <<= 8;
        n |= m_pdata[6];
        n <<= 8;
        n |= m_pdata[7];
        m_pdata += 8;
        assert(m_pfree>=m_pdata);
        return n;
    }

    bool readBytes(void *dst, int len) {
        if (m_pdata + len > m_pfree) {
            return false;
        }
        memcpy(dst, m_pdata, len);
        m_pdata += len;
        assert(m_pfree>=m_pdata);
        return true;
    }

    /*
     * 写字符串
     */
    bool readString(char *&str, int len) {
        if (m_pdata + sizeof(int) > m_pfree) {
            return false;
        }
        int slen = readInt32();
        if (m_pfree - m_pdata < slen) {
            slen = static_cast<int32_t>(m_pfree - m_pdata);
        }
        if (str == NULL && slen > 0) {
            str = (char*)malloc(slen);
            len = slen;
        }
        if (len > slen) {
            len = slen;
        }
        if (len > 0) {
            memcpy(str, m_pdata, len);
            str[len-1] = '\0';
        }
        m_pdata += slen;
        assert(m_pfree>=m_pdata);
        return true;
    }

    /**
     * 读取一列表
     */
    bool readVector(std::vector<int32_t>& v) {
         const uint32_t len = readInt32();
         for (uint32_t i = 0; i < len; ++i) {
             v.push_back(readInt32());
         }
         return true; 
    }

    bool readVector(std::vector<uint32_t>& v) {
         const uint32_t len = readInt32();
         for (uint32_t i = 0; i < len; ++i) {
             v.push_back(readInt32());
         }
         return true; 
    }

    bool readVector(std::vector<int64_t>& v) {
         const uint32_t len = readInt32();
         for (uint32_t i = 0; i < len; ++i) {
             v.push_back(readInt64());
         }
         return true; 
    }

    bool readVector(std::vector<uint64_t>& v) {
         const uint32_t len = readInt32();
         for (uint32_t i = 0; i < len; ++i) {
             v.push_back(readInt64());
         }
         return true; 
    }

    /*
     * 确保有len的空余空间
     */
    void ensureFree(int len) {
        expand(len);
    }

    /*
     * 寻找字符串
     */
    int findBytes(const char *findstr, int len) {
        int dLen = static_cast<int32_t>(m_pfree - m_pdata - len + 1);
        for (int i=0; i<dLen; i++) {
            if (m_pdata[i] == findstr[0] && memcmp(m_pdata+i, findstr, len) == 0) {
                return i;
            }
        }
        return -1;
    }

private:
    /*
     * expand
     */
    inline void expand(int need) {
        if (m_pstart == NULL) {
            int len = 256;
            while (len < need) len <<= 1;
            m_pfree = m_pdata = m_pstart = (unsigned char*)malloc(len);
            m_pend = m_pstart + len;
        } else if (m_pend - m_pfree < need) { // 空间不够
            int flen = static_cast<int32_t>((m_pend - m_pfree) + (m_pdata - m_pstart));
            int dlen = static_cast<int32_t>(m_pfree - m_pdata);

            if (flen < need || flen * 4 < dlen) {
                int bufsize = static_cast<int32_t>((m_pend - m_pstart) * 2);
                while (bufsize - dlen < need)
                    bufsize <<= 1;

                unsigned char *newbuf = (unsigned char *)malloc(bufsize);
                if (newbuf == NULL)
                {
					//Athena::logger->error("expand data buffer failed, length: %d", bufsize);
                }
                assert(newbuf != NULL);
                if (dlen > 0) {
                    memcpy(newbuf, m_pdata, dlen);
                }
                free(m_pstart);

                m_pdata = m_pstart = newbuf;
                m_pfree = m_pstart + dlen;
                m_pend = m_pstart + bufsize;
#ifdef _HDZ_DEBUG
				//Athena::logger->trace("发送缓冲不够,重新分配了内存!");
#endif
            } else {
				/*if (dlen && (m_pdata - m_pstart > dlen))*/{
					memmove(m_pstart, m_pdata, dlen);
					m_pfree = m_pstart + dlen;
					m_pdata = m_pstart;
#ifdef _HDZ_DEBUG
					//Athena::logger->trace("整理了发送缓冲,expend,free len=%d,data len=%d",flen,dlen);
#endif
				}
            }
        }
    }


private:
    unsigned char *m_pstart;      // buffer开始
    unsigned char *m_pend;        // buffer结束
    unsigned char *m_pfree;        // free部分
    unsigned char *m_pdata;        // data部分
};

}

#endif /*PACKET_H_*/
