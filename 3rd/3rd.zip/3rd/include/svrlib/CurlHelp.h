#ifndef __H_CURL_HELP_H__
#define __H_CURL_HELP_H__
#include "curl.h"
#include "TypesDef.h"
#include "HttpRequest.h"
#include <vector>
#include <string>

typedef size_t (*write_callback)(void *ptr, size_t size, size_t nmemb, void *stream);

class CCurlHelp
{
    //curl实例
	CURL *m_curl;
    //请求头
    curl_slist *m_headers;
public:
	//构造函数
    CCurlHelp();
	//析构函数
    ~CCurlHelp();
	//配置curl相关参数	
	bool configureCURL(CURL *handle);
   	//设置选项 
	template <class T>
    bool setOption(CURLoption option, T data);
	//初始化回调函数等等
    bool init(CHttpRequest *request, write_callback callback, void *stream, write_callback headerCallback, void *headerStream);
	//执行跟远程服务器交互
    bool perform(INT64 *responseCode);
};

//设置选项 
template <class T>
bool CCurlHelp::setOption(CURLoption option, T data)
{
	return CURLE_OK == curl_easy_setopt(m_curl, option, data);
}
#endif
