#ifndef __HTTP_RESPONSE__
#define __HTTP_RESPONSE__
#include "HttpRequest.h"

class CHttpResponse
{
public:
	//构造函数
    CHttpResponse(CHttpRequest* request)
    {
        m_pHttpRequest = request;
        m_succeed = false;
        m_responseData.clear();
        m_errorBuffer.clear();
    }
	//析构函数
    virtual ~CHttpResponse()
    {
		SAFE_DELETE(m_pHttpRequest);
    }
   	//获得http请求 
    inline CHttpRequest* getHttpRequest()
    {
        return m_pHttpRequest;
    }
    //是否成功    
    inline bool isSucceed()
    {
        return m_succeed;
    };
   	//获得相应 
    inline std::vector<char>* getResponseData()
    {
        return &m_responseData;
    }
   	//获得相应头 
    inline std::vector<char>* getResponseHeader()
    {
        return &m_responseHeader;
    }
	//获得http响应码
    inline int getResponseCode()
    {
        return m_responseCode;
    }
	//错误数据
    inline const char* getErrorBuffer()
    {
        return m_errorBuffer.c_str();
    }
    //设置http请求是否成功
	inline void setSucceed(bool value)
    {
        m_succeed = value;
    };
    //设置响应数据
	inline void setResponseData(std::vector<char>* data)
    {
        m_responseData = *data;
    }
	//设置响应头
    inline void setResponseHeader(std::vector<char>* data)
    {
        m_responseHeader = *data;
    }
	//设置响应码
    inline void setResponseCode(int value)
    {
        m_responseCode = value;
    }
    //设置错误信息
	inline void setErrorBuffer(const char* value)
    {
        m_errorBuffer.clear();
        m_errorBuffer.assign(value);
    };
protected:
    bool initWithRequest(CHttpRequest* request);
    CHttpRequest*        m_pHttpRequest;  	//所对应的CHttpRequest
    bool                  m_succeed;        //是否成功 
    std::vector<char>     m_responseData;   //返回数据
    std::vector<char>     m_responseHeader; //返回的头
    int                   m_responseCode;   //返回码 200,301,404等等
    std::string           m_errorBuffer;   /// 当m_responseCode != 200,错误返回的错误码
};
#endif //__HTTP_RESPONSE_H__
