#ifndef  __MYSQLCONNPOOL_H__
#define __MYSQLCONNPOOL_H__

#include <ext/hash_map>
#include <string>
#include "mysql.h"
#include "TypesDef.h"
#include "Time.h"
#include "ThreadMutex.h"
#include "Singleton.h"

enum MysqlConnState
{
	MYSQL_CONN_STATE_INVALID = -1,	//无效状态
	MYSQL_CONN_STATE_FREE  = 1,		//可用
	MYSQL_CONN_STATE_BUSY = 2,		//使用中
};

struct stMysqlUrl
{
	std::string host, port, user, password, database;
	stMysqlUrl()
	{
		host = "";
		port = "";
		user = "";
		password = "";
		database = "";
	}
};

class CMysqlConn
{
	public :
		//构造函数
		CMysqlConn()
		{
			m_connState = MYSQL_CONN_STATE_INVALID;	
			m_connID = ++MYSQL_CONNID;
			m_mysql = NULL;
			m_lastsql = "";
			RealTime cur;
			m_initTime = cur.msecs();
			m_useTime = 0;
			m_useCount = 0;
		}
		//析构函数
		~CMysqlConn()
		{
			m_connState = MYSQL_CONN_STATE_INVALID;	
			m_connID = 0;
			finalMysql();
		}
		//获取连接标志
		UINT32 getConnID()
		{
			return m_connID;
		}
		//设置最后依次使用该连接的sql
		void setLastSql(std::string sql)
		{
			m_lastsql = sql;
		}
		//获得最后一次使用该连接的sq
		std::string getLastSql()
		{
			return m_lastsql;
		}
		//初始化连接
		bool initMysql();
		/**
		 * @Brief  finalMysql 结束连接 
		 *
		 * @Returns   
		 */

		bool finalMysql();
		
		/**
		 * @Brief  setMysqlUrl 设置连接参数 
		 *
		 * @Param url
		 */
		void setMysqlUrl(stMysqlUrl & url)
		{
			m_url.host = url.host;
			m_url.port = url.port;
			m_url.user = url.user;
			m_url.password = url.password;
			m_url.database = url.database;
		}
		
		/**
		 * @Brief  setState 设置为使用状态 
		 *
		 * @Returns   
		 */
		bool setState();

		/**
		 * @Brief  unsetState 设置为可用状态 
		 *
		 * @Returns   
		 */
		bool unsetState();
		
		/**
		 * @Brief  canUse 判断是否可用 
		 *
		 * @Returns   
		 */
		bool canUse()
		{
			return m_connState == MYSQL_CONN_STATE_FREE; 
		}
		/**
		 * @Brief 是否正在使用
		 *
		 * @Returns true正在使用 false反之
		 * */
		
		bool isUsed()
		{
			return m_connState == MYSQL_CONN_STATE_BUSY; 
		}
		
		/**
		 * @Brief 已经使用了的时间
		 *
		 * @Returns 返回使用的时间
		 * **/
		
		UINT64 hasUseTime();

		MYSQL * getMysql()
		{
			return m_mysql;
		}

	private :
		static UINT32  MYSQL_CONNID ;    //连接的标志自动生成器
		MysqlConnState m_connState;		 //连接的状态
		UINT32  m_connID;					 //当前连接标志
		MYSQL * m_mysql;
		stMysqlUrl m_url;
		std::string m_lastsql;			//最后使用该连接的sql语句
		UINT64  m_initTime;				//该连接创建时间
		UINT64  m_useTime;				//某个sql语句使用时间
		UINT32  m_useCount;					//使用次数
};

class  CMysqlConnPool
{
	private :
		CMysqlConnPool();

	
		USE_SINGLETON_NEW(CMysqlConnPool)
	public :
		static CMysqlConnPool &  instance()
		{   
			return THE_SINGLETON::Instance();
		}
		
		static void destroyMe()
		{
			THE_SINGLETON::destroy();
		}

		~CMysqlConnPool();
	
		/**
		 * @Brief  initPool 初始化连接池
		 *
		 * @Param host 服务器的ip
		 * @Param port 端口
		 * @Param user 用户名字
		 * @Param password 密码
		 * @Param database 数据库
		 *
		 * @Returns  是否成功 
		 */
		bool initPool(std::string & host,std::string & port,std::string & user,std::string & password,std::string & database);

		/**
		 * @Brief  getConn  获得一个连接 
		 *
		 * @Returns   
		 */
		CMysqlConn * getConn();

		/**
		 * @Brief  putConn 释放连接 
		 *
		 * @Param id
		 */
		void putConn(UINT32 id);
		/*
		 * @Brief 显示连接情况
		 */	
		void showPool();
		/*
		 * @brief 设置当前访问的数据库
		 */
		void setCurDatabaseID(UINT16 id) { m_curDatabaseID = id ; }
		/*
		 * @breif 获得当前数据库 ID
		 */
		UINT16 getCurDatabaseID() {  return m_curDatabaseID ;}
	public :
		typedef std::map<UINT16,__gnu_cxx::hash_map<UINT32,CMysqlConn *> >  ConnCtn;
		typedef __gnu_cxx::hash_map<UINT32,CMysqlConn *>::iterator  ConnCtn_IT;
	private :
		ConnCtn  m_connCtns;
		const static UINT32  minConnCount = 2;			//连接最少数目
		const static UINT32  maxConnCount = 48;			//连接最大数目
		const static UINT64  alertHasUsedTime = 500;	//占用时间的警告上限
		static UINT16  s_HOST_DATABASE_GENID ;			//数据库的ID
		stMysqlUrl  m_url;								//mysql数据库的地址
		UINT16  m_curDatabaseID;						//当前的数据库ID
		Mutex  	m_mutex;							//互斥锁
};

#define mysqlConnPool   CMysqlConnPool::instance()

#endif
