#ifndef __TBL_FIELD_H__
#define __TBL_FIELD_H__
#include "TypesDef.h"
#include <string>
#include <vector>
#include <strings.h>
#include <stdlib.h>

struct CTblField
{
    public:

		/**
		 * @Brief  数据库的类型
		 */
        enum DataTypes
        {
            DB_TYPE_NONE = 0x00,
            DB_TYPE_STRING  = 0x01,
			DB_TYPE_INT8    = 0x02,
			DB_TYPE_UINT8   = 0x03,
			DB_TYPE_INT16   = 0x04,
			DB_TYPE_UINT16  = 0x05,
			DB_TYPE_INT32   = 0x06,
			DB_TYPE_UINT32  = 0x07,
			DB_TYPE_INT64   = 0x08,
			DB_TYPE_UINT64  = 0x09,
            DB_TYPE_FLOAT   = 0x0A,
			DB_TYPE_BLOB    = 0x0B,
        };
		
      //  CTblField() : m_name(NULL),m_type(0),m_size(0){	}
       // ~CTblField(){}
    public:
		const char*     m_name;       //字段名称
		INT32           m_type;       //DB数据类型
		UINT32    		m_size;       //数据长度
};
#endif
