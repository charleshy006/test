/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_SOCKET_H__
#define __NET_SOCKET_H__
#include <string>

namespace net
{
	class Socket
	{
		public:
			/*
			 * 构造函数
			 */
			Socket();

			/*
			 * 析构函数
			 */
			~Socket();

			/*
			 * 设置地址
			 *
			 * @param address  host或ip地址
			 * @param port  端口号
			 * @return 是否成功
			 */

			bool setAddress (const char *address, const int port);

			/*
			 * 连接到_address上
			 *
			 * @return 是否成功
			 */
			bool connect();

			/**
			 * 关闭连接
			 */
			void close();

			/*
			 * 关闭读写
			 */
			void shutdown();

			/*
			 * 把socketHandle,及ipaddress设置到此socket中
			 *
			 * @param  socketHandle: socket的文件句柄
			 * @param hostAddress: 服务器地址
			 */

			void setUp(int socketHandle, struct sockaddr *hostAddress);

			/*
			 * 返回文件句柄
			 *
			 * @return 文件句柄
			 */
			int getSocketHandle();

			/*
			 * 返回IOComponent
			 *
			 * @return  IOComponent
			 */
			IOComponent *getIOComponent();

			/*
			 * 设置IOComponent
			 *
			 * @param IOComponent
			 */
			void setIOComponent(IOComponent *ioc);

			/*
			 * 写数据
			 */
			int write(const void *data, int len);

			/*
			 * 读数据
			 */
			int read(void *data, int len);

			/*
			 * SetSoKeepAlive
			 */
			bool setKeepAlive(bool on) {
				return setIntOption(SO_KEEPALIVE, on ? 1 : 0);
			}

			/*
			 * setReuseAddress
			 */
			bool setReuseAddress(bool on) {
				return setIntOption(SO_REUSEADDR, on ? 1 : 0);
			}

			/*
			 * setSoLinger
			 */
			bool setSoLinger (bool doLinger, int seconds);

			/*
			 * setTcpNoDelay
			 */
			bool setTcpNoDelay(bool noDelay);

			/*
			 * setTcpQuickAck
			 */
			bool setTcpQuickAck(bool quickAck);

			/*
			 * setIntOption
			 */
			bool setIntOption(int option, int value);

			/*
			 * setTimeOption
			 */
			bool setTimeOption(int option, int milliseconds);

			/*
			 * 是否阻塞
			 */
			bool setSoBlocking(bool on);

			/*
			 * 检查Socket句柄是否创建
			 */
			bool checkSocketHandle();

			/*
			 * 得到Socket错误
			 */
			int getSoError();

			/*
			 * 得到ip地址,包括端口 写到tmp上
			 */
			std::string getAddr();
			
			/*
			 *  只返回对端ip,不包括IP
			 */
			std::string getIP();

			/*
			 * 得到64位数字的ip地址
			 */
			uint64_t getId();
			uint64_t getPeerId();

			/**
			 * 得到本地端口
			 */
			int getLocalPort();


			/*
			 * 得到最后的错误
			 */
			static int getLastError() {
				return errno;
			}

		protected:
			struct sockaddr_in  m_address; 	// 地址
			int m_socketHandle;    			// socket文件句柄
			IOComponent *m_iocomponent;
			static Mutex m_dnsMutex; 		// 多实例用一个dnsMutex
	};
}

#endif /*__NET_SOCKET_H__*/
