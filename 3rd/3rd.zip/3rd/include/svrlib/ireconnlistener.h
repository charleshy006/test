#ifndef __H_RECONNLISTNER_H__
#define __H_RECONNLISTNER_H__
#include "net.h"

namespace net
{
	class IReConnListener
	{
		public :
			//构造函数
			IReConnListener() {}
			//析构函数
			virtual ~IReConnListener() {}
			//连接服务器成功
			virtual void onConnectSvrSucess(TCPComponent  *pTcpCom) = 0;
			//断开连接
			virtual void onDisConnect(TCPComponent  *pTcpCom) = 0;
	};
};
#endif
