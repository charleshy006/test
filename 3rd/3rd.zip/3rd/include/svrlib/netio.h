/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_CONNECTION_H__
#define __NET_CONNECTION_H__

//#define READ_WRITE_SIZE 8192
#define READ_WRITE_SIZE 65535
#ifndef UNUSED
#define UNUSED(v) ((void)(v))
#endif

namespace net
{
	class NetIO 
	{
		public:
			/*
			 * 构造函数
			 */
			NetIO(Socket *socket, IPacketSpliter * spliter, IPacketHandler *serverAdapter);

			/*
			 * 析造函数
			 */
			virtual ~NetIO();

			/*
			 * 设置是否为服务器端
			 */
			void setServer(bool isServer) {
				m_isServer = isServer;
			}
			
			/*
			 * 是否为服务端
			 */
			bool isServer()
			{ return m_isServer ;}

			void setIOComponent(IOComponent *ioc) {
				m_iocomponent = ioc;
			}

			IOComponent *getIOComponent() {
				return m_iocomponent;
			}
			/*
			 * 设置默认的packetHandler
			 */
			void setDefaultPacketHandler(IPacketHandler *ph) {
				m_defaultPacketHandler = ph;
			}

			/*
			 * 发送packet到发送队列
			 *
			 * @param packet: 数据包
			 * @param timeout: 超时时间
			 */
			bool postPacket(Packet *packet);

			/*
			 * 当数据收到时的处理函数
			 */
			bool handlePacket(DataBuffer *input, PacketHeader *header);

			/*
			 * 检查超时
			 */
			bool checkTimeout(int64_t now);

			/*
			 * 写出数据
			 */
			virtual bool writeData() = 0;

			/*
			 * 读入数据
			 */
			virtual bool readData() = 0;

			/*
			 * 设置写完是否关闭, 只TCP要用
			 */
			virtual void setWriteFinishClose(bool v) {
				UNUSED(v);
			}

			/*
			 * 清空output的buffer
			 */
			virtual void clearOutputBuffer() {
			}

			/**
			 * 连接状态
			 */
			bool isConnectState();

			/**
			 * localPort
			 */
			int getLocalPort() {
				if (m_socket) {
					return m_socket->getLocalPort();
				}
				return -1;
			}

			/**
			 * m_hasBeatHeart
			 */
			void  setHasBeatHeart(bool hasBeatHeart) 
			{
				m_hasBeatHeart = hasBeatHeart;
			}

			/*
			 * 发送心跳包
			 */
			void sendBeatHeart();
		protected:
			static const int64_t s_BEAT_HEAT_INTERVAL = 60000;//1分钟一次心跳
			IPacketHandler *m_defaultPacketHandler;  // connection的默认的packet handler
			bool m_isServer;                         // 是服务器端
			IOComponent *m_iocomponent;
			Socket *m_socket;                        // Socket句柄
			IPacketSpliter *m_spliter;               // Packet解析
			IPacketHandler *m_serverAdapter;         // 服务器适配器

			PacketQueue m_outputQueue;               // 发送队列
			PacketQueue m_inputQueue;                // 接受缓存队列
			PacketQueue m_myQueue;                   // 在write中处理时暂时用
			Mutex m_outputCond;         			// 发送队列的条件变量

			int m_failBeatHeartNum;					// 失败的心跳次数
			bool m_sendBeatHeart;					// 已经发送了心跳
			bool m_hasBeatHeart;					// 是否有心跳
			int64_t m_lastBeatHeartTime;			// 上次心跳时间

			bool m_mThreadProcessPack;				//多线程处理包
			PacketProcessorBase *m_pPacketPocessor; //处理包中心
	};
}
#endif /*__NET_CONNECTION_H__*/
