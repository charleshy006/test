/*
 * (C) 2013 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_IPACKETHANDLER_H__
#define __NET_IPACKETHANDLER_H__

namespace net
{
	class IPacketHandler 
	{
		public:
			virtual ~IPacketHandler() {}
			virtual  bool handlePacket(IOComponent *pConn, Packet *packet) = 0;
	};
}

#endif /*__NET_IPACKETHANDLER_H__*/
