#ifndef __H_SQLDELAYTHREADPOOL_H__
#define __H_SQLDELAYTHREADPOOL_H__
#include "SqlDelayThread.h"
#include <vector>
#include "Database.h"
#include "SqlOperation.h"

class SqlDelayThreadPool
{
	public :
		USE_SINGLETON_NEW(SqlDelayThreadPool);
	public :
		static const UINT16 MAX_THREAD_NUM = 1;
	private :
		SqlDelayThreadPool(){}
	public :
		static SqlDelayThreadPool & getSingleton()
		{
			return THE_SINGLETON::Instance();
		}
		static void destroyMe()
		{
			THE_SINGLETON::destroy();
		}
		~SqlDelayThreadPool();
		bool init(CDatabase *db);
		void delay(CSqlOperation * sqlOp);
		void processAllCB();
	private :
		std::vector<CSqlDelayThread *> m_threadPool;
};

#endif
