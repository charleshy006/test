#ifndef _CLIENT_PACKET_STREAMER_H_
#define _CLIENT_PACKET_STREAMER_H_
#include "net.h"

namespace net
{
	class ClientBinPacketSpliter : public IPacketSpliter 
	{
		public :
			static const int  s_CLIENT_PACKET_HEADER_LEN  = 10;
		public:
			/*
			 * 构造函数
			 */
			ClientBinPacketSpliter();

			/*
			 * 构造函数
			 */
			ClientBinPacketSpliter(IPacketFactory *factory);

			/*
			 * 析构函数
			 */
			~ClientBinPacketSpliter();

			/*
			 * 设置包工厂
			 */
			void setPacketFactory(IPacketFactory *factory);

			/*
			 * 设置包头
			 */
			bool getPacketInfo(DataBuffer *input, PacketHeader *header, bool *broken);

			/*
			 * 解码
			 */
			Packet *decode(DataBuffer *input, PacketHeader *header);

			/*
			 * 编码
			 */
			bool encode(Packet *packet, DataBuffer *output);
	};
}/*_CLIENT_PACKET_STREAMER_H_*/
#endif
