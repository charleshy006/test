#ifndef __H_BYTEBUFFER_H_
#define __H_BYTEBUFFER_H_

#include <list>
#include <vector>
#include <map>
#include <string>
#include <assert.h>
#include <algorithm>
#include "TypesDef.h"
#include "ByteOrder.h"

class ByteBuffer
{
public:
	const static size_t DEFAULT_SIZE = 0x1000;

	ByteBuffer();
	ByteBuffer(size_t res);
	ByteBuffer(const ByteBuffer & buf);
	virtual ~ByteBuffer();

	void clear();

	template<typename T> inline void append(T value)
	{
		append((UINT8*) &value, sizeof(value));
	}
	
	template<typename T> inline void put(size_t pos, T value)
	{
		put(pos, (UINT8*) &value, sizeof(value));
	}
	
	template<typename T> inline T read()
	{
		T r = read<T> (_rpos);
		_rpos += sizeof(T);
		return r;
	}

	template<typename T> inline T read(size_t pos) const
	{
		if (pos + sizeof(T) > size())
		{
			return (T) 0;
		}
		else
		{
			return *((T*) &_storage[pos]);
		}
	}

	ByteBuffer & operator << (bool value);
	ByteBuffer & operator << (UINT8 value);
	ByteBuffer & operator<<(UINT16 value);
	ByteBuffer & operator<<(UINT32 value);
	ByteBuffer & operator<<(UINT64 value);
	ByteBuffer & operator<<(INT8 value);
	ByteBuffer & operator<<(INT16 value);
	ByteBuffer & operator<<(INT32 value);
	ByteBuffer & operator<<(INT64 value);
	ByteBuffer & operator<<(float value);
	ByteBuffer & operator<<(double value);
	ByteBuffer & operator<<(const std::string & value);
	ByteBuffer & operator<<(const char* str);
	ByteBuffer & operator>>(bool & value);
	ByteBuffer & operator>>(UINT8 & value);
	ByteBuffer & operator>>(UINT16 & value);
	ByteBuffer & operator>>(UINT32 & value);
	ByteBuffer & operator>>(UINT64 & value);
	ByteBuffer & operator>>(INT8 & value);
	ByteBuffer & operator>>(INT16 & value);
	ByteBuffer & operator>>(INT32 & value);
	ByteBuffer & operator>>(INT64 & value);
	ByteBuffer & operator>>(float & value);
	ByteBuffer & operator>>(double & value);
	ByteBuffer & operator>>(std::string & value);
	UINT8 operator[](size_t pos);

	size_t rpos();
	size_t rpos(size_t rpos);
	size_t wpos();
	size_t wpos(size_t wpos);

	void read(UINT8* dest, size_t len);
	const UINT8* contents() const;
	size_t size() const;
	size_t remaing() const;
	void resize(size_t newsize);
	void reserve(size_t ressize);
	void append(const std::string & str);
	void append(const char* src, size_t cnt);
	void append(const UINT8* src, size_t cnt);
	void append(const ByteBuffer & buffer);
	void appendPackGUID(UINT64 guid);
	UINT64 unpackGUID();

	void put(size_t pos, const UINT8* src, size_t cnt);

	void hexlike();
	void reverse();

protected:
	size_t _rpos, _wpos;
	std::vector<UINT8> _storage;
};

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

template<typename T> inline ByteBuffer & operator<<(ByteBuffer & b, std::vector<T> v)
{
	b << endianSwap2<UINT16>((UINT16) v.size());
	for (typename std::vector<T>::iterator i = v.begin(); i != v.end(); i++)
	{
		b << *i;
	}
	return b;
}
template<typename T> inline ByteBuffer & operator>>(ByteBuffer & b, std::vector<T> &v)
{
	UINT16 vsize;
	b >> vsize;
	vsize = endianSwap2<UINT16>(vsize);
	v.clear();
	while (vsize--)
	{
		T t;
		b >> t;
		v.push_back(t);
	}
	return b;
}
template<typename T> inline ByteBuffer & operator<<(ByteBuffer & b, std::list<T> v)
{
	b << endianSwap2<UINT16>((UINT16) v.size());
	for (typename std::list<T>::iterator i = v.begin(); i != v.end(); i++)
	{
		b << *i;
	}
	return b;
}
template<typename T> inline ByteBuffer & operator>>(ByteBuffer & b, std::list<T> &v)
{
	UINT16 vsize;
	b >> vsize;
	vsize = endianSwap2<UINT16>(vsize);
	v.clear();
	while (vsize--)
	{
		T t;
		b >> t;
		v.push_back(t);
	}
	return b;
}
template<typename K, typename V> inline ByteBuffer & operator<<(ByteBuffer & b,
	std::map<K, V> &m)
{
	b << endianSwap2<UINT16>((UINT16) m.size());
	for (typename std::map<K, V>::iterator i = m.begin(); i != m.end(); i++)
	{
		b << i->first << i->second;
	}
	return b;
}
template<typename K, typename V> inline ByteBuffer & operator>>(ByteBuffer & b,
	std::map<K, V> &m)
{
	UINT16 msize;
	b >> msize;
	msize = endianSwap2<UINT16>(msize);
	m.clear();
	while (msize--)
	{
		K k;
		V v;
		b >> k >> v;
		m.insert(make_pair(k, v));
	}
	return b;
}
#endif
