#ifndef __TIMERTHREAD_H__
#define __TIMERTHREAD_H__
#include "Time.h"
#include "TypesDef.h"

//定时器回调
struct stTimerCB
{
	unsigned int m_interval;        //时间间隔以毫秒为单位
	unsigned long long m_lastTime;
	bool canExc(unsigned long long curTime)
	{
		return curTime > m_lastTime + m_interval;
	}
	stTimerCB(unsigned int _interval) : m_interval(_interval),m_lastTime(0)
	{
		
	}
	virtual ~stTimerCB(){}
	//curTime 单位为毫秒,返回false表示将删除该回调
	virtual bool exec(RealTime & curTime) { return true; }
};

//定时器线程
class TimerMgr 
{
	public:
		static RealTime currentTime;
		//构造函数
		TimerMgr();
		//析构函数
		virtual ~TimerMgr();
		//循环运行
		void run();
		//增加一个回调
		void addTimer(stTimerCB* cb);
		//每一帧的检查
		UINT32 checkTimeOut();
		//服务器关闭时候的调用
		void addShutdownCB(stTimerCB* cb);
		//停止
		void stop() { m_stop = true ;}
	private:
		typedef std::vector<stTimerCB*> TimerVec;
		TimerVec m_timerVec;						/// 定时器回调容器
		TimerVec m_shutDownCB;						/// 关闭时候调用
		static const UINT64 timeout_value = 500;
		bool m_stop;
};

#endif
