#include <time.h>
#include <limits.h>

class FastRandom
{
	/// <summary>
	/// A static RNG that is used to generate seed values when constructing new instances of FastRandom.
	/// This overcomes the problem whereby multiple FastRandom instances are instantiated within the same
	/// tick count and thus obtain the same seed, that approach can result in extreme biases occuring 
	/// in some cases depending on how the RNG is used.
	/// </summary>
	static FastRandom __seedRng ;

	// The +1 ensures NextDouble doesn't generate 1.0
	static double REAL_UNIT_INT ;
	static double REAL_UNIT_UINT;
	static const unsigned int Y=842502087, Z=3579807591, W=273326509;

	unsigned int _x, _y, _z, _w;
	unsigned int _bitBuffer;
	unsigned  int _bitMask;
	public :
	/// <summary>
	/// Initialises a new instance using a seed generated from the class's static seed RNG.
	/// </summary>
	FastRandom();

	/// <summary>
	/// Initialises a new instance using an int value as seed.
	/// This constructor signature is provided to maintain compatibility with
	/// System.Random
	/// </summary>
	FastRandom(int seed);


	/// <summary>
	/// Reinitialises using an int value as a seed.
	/// </summary>
	void Reinitialise(int seed);

	/// <summary>
	/// Generates a random int over the range 0 to int.MaxValue-1.
	/// MaxValue is not generated in order to remain functionally equivalent to System.Random.Next().
	/// This does slightly eat into some of the performance gain over System.Random, but not much.
	/// For better performance see:
	/// 
	/// Call NextInt() for an int over the range 0 to int.MaxValue.
	/// 
	/// Call NextUInt() and cast the result to an int to generate an int over the full Int32 value range
	/// including negative values. 
	/// </summary>
	int Next();

	/// <summary>
	/// Generates a random int over the range 0 to upperBound-1, and not including upperBound.
	/// </summary>
	int Next(int upperBound);

	/// <summary>
	/// Generates a random int over the range lowerBound to upperBound-1, and not including upperBound.
	/// upperBound must be >= lowerBound. lowerBound may be negative.
	/// </summary>
	int Next(int lowerBound, int upperBound);

	/// <summary>
	/// Generates a random double. Values returned are over the range [0, 1). That is, inclusive of 0.0 and exclusive of 1.0.
	/// </summary>
	double NextDouble();

	/// <summary>
	/// Generates a uint. Values returned are over the full range of a uint, 
	/// uint.MinValue to uint.MaxValue, inclusive.
	/// 
	/// This is the fastest method for generating a single random number because the underlying
	/// random number generator algorithm generates 32 random bits that can be cast directly to 
	/// a uint.
	/// </summary>
	unsigned int NextUInt();

	/// <summary>
	/// Generates a random int over the range 0 to int.MaxValue, inclusive. 
	/// This method differs from Next() only in that the range is 0 to int.MaxValue
	/// and not 0 to int.MaxValue-1.
	/// 
	/// The slight difference in range means this method is slightly faster than Next()
	/// but is not functionally equivalent to System.Random.Next().
	/// </summary>
	int NextInt();

	/// <summary>
	/// Generates a random double. Values returned are over the range (0, 1). That is, exclusive of both 0.0 and 1.0.
	/// </summary>
	double NextDoubleNonZero();
	// Buffer 32 bits in bitBuffer, return 1 at a time, keep track of how many have been returned
	// with bitMask.

	/// <summary>
	/// Generates a single random bit.
	/// This method's performance is improved by generating 32 bits in one operation and storing them
	/// ready for future calls.
	/// </summary>
	bool NextBool();
};

