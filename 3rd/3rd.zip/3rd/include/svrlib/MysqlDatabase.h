#ifndef __CMYSQLDATABASE_H__
#define __CMYSQLDATABASE_H__

#include "mysql.h"
#include "Database.h"
#include "SqlOperation.h"
#include "TblField.h"

class CMysqlDatabaseMgr : public CDatabase
{
	private:
		CMysqlDatabaseMgr();

		USE_SINGLETON_NEW(CMysqlDatabaseMgr)	
    public:
		~CMysqlDatabaseMgr();
		static CMysqlDatabaseMgr &  instance()
		{
			return THE_SINGLETON::Instance();
		}
		static void destroyMe()
		{
			THE_SINGLETON::destroy();
		}
		//启动的使用调用
        void threadStart();
		//线程结束的时候调用
        void threadEnd();
		//初始化
        bool initialize(const char *szInfo_);
		// 进行查询
        CTblQueryResult* query(const char *szSql_,const UINT32 &len,const char * logSql);
		//直接执行
        bool directExecute(const char* szSql_,const UINT32 &len,const char * logSql);
		//开始事务
        bool beginTransaction();
		//提交事务
        bool commitTransaction();
		//回滚事务
        bool rollbackTransaction();
		//字符串处理
        unsigned long escape_string(char *szTo, const char *szFrom, unsigned long length);
        using CDatabase::escape_string;
		//列出所有表
		CTblQueryResult * listTable(CTblField * dbColDef,const char * pTableName);
	public :
		/**
		 * @Brief  select 查询记录
		 *
		 * @Param dbColDef 表结构定义
		 * @Param szTblName 表名字
		 * @Param szWhere 查询条件
		 * @Param szOderby 排序方式
		 * @Param delaySql 是否延迟执行
		 *
		 * @Returns   返回记录集 返回的值是New出来的,一定要记得释放
		 */
		CTblQueryResult * select(CTblField * dbColDef,const char * szTblName,const char * szWhere,const char *szOderby,UINT32 limit = 0,CSqlOperation * delaySql = NULL,UINT32 from = 0);
			
			/**
			 * @Brief  insert  插入操作 
			 *
			 * @Param dbColDef 插入操作
			 * @Param szTblName 表名字
			 * @Param autoIncID 自动增长ID
			 * @Param delaySql是否延迟执行
			 *
			 * @Returns   
			 */
			bool  insertRecord(CTblField * dbColDef,const char * data,const char * szTblName,UINT64 & autoIncID,CSqlOperation * delaySql = NULL);
			
			/**
			 * @Brief  update 更新操作 
			 *
			 * @Param dbColDef 表格字段的定义
			 * @Param szTblName 表格名字
			 * @Param szWhere  更新条件
			 * @Param delaySql 是否延迟执行
			 *
			 * @Returns   
			 */
			bool  updateRecord(CTblField * dbColDef,const char * data,const char * szTblName,const char * szWhere,CSqlOperation * delaySql = NULL);
			
			/**
			 * @Brief  deleteRecord 
			 *
			 * @Param szTblName
			 * @Param szWhere
			 * @Param delaySql 是否延迟执行
			 *
			 * @Returns   
			 */
			bool  deleteRecord(const char * szTblName,const char * szWhere,CSqlOperation * delaySql = NULL);
        private:
       		static size_t db_count;
			Mutex  m_mutex;

};

#endif
