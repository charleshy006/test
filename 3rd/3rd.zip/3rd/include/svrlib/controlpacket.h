/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_CONTROL_PACKET_H__
#define __NET_CONTROL_PACKET_H__
#ifndef UNUSED
#define UNUSED(v) ((void)(v))
#endif

namespace net
{
	class ControlPacket : public Packet {
		public:
			enum {
				CMD_BAD_PACKET = 1,
				CMD_TIMEOUT_PACKET,
				CMD_DISCONN_PACKET
			};

			static ControlPacket BadPacket;
			static ControlPacket TimeoutPacket;
			static ControlPacket DisconnPacket;

		public:
			/*
			 * 构造函数, 传包类型
			 */
			ControlPacket(int c) : m_command(c) {}

			/*
			 * 是否数据包
			 */
			bool isRegularPacket() {
				return false;
			}

			void free() {}

			/*
			 * 计算出数据包的长度
			 */
			void countDataLen() {}

			/*
			 * 组装
			 */
			bool encode(DataBuffer *output,bool bZip) {
				UNUSED(output);
				return false;
			}

			/*
			 * 解开
			 */
			bool decode(DataBuffer *input, PacketHeader *header,bool bZip) {
				UNUSED(input);
				UNUSED(header);
				return false;
			}

			/*
			 * 得到类型
			 */
			int getCommand() {
				return m_command;
			}

			/*
			 * 是否是控制包
			 */
			static bool isControlPacket(Packet * pPacket);
		private:
			int m_command;
	};

}

#endif /*__NET_CONTROL_PACKET_H__*/
