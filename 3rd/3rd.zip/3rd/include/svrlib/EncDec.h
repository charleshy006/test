#ifndef __ENCDEC_H__
#define __ENCDEC_H__
#include "TypesDef.h"
#include "DesEcb.h"

class EncDecHelper
{
public:
	EncDecHelper();
	//设置密钥
	void setEcbkey(char * key);
	//加解密
	int encdec(void* inData, UINT32 inSize, void* outBuff, UINT32 buffSize, bool enc);
	//设置加密方法
	void setEncDecMethod(eEncDecMethod method);
	//获得加解密方法
	eEncDecMethod getEncMethod() const;
private:
	bool m_isSetEcb;    			// 是否设置了 ecb
	char  m_desEcbKey[8];			// ecb的密钥
	eEncDecMethod m_method;			//加密方法
	DesEcbHelper m_desEcbHelper;	//ecb加解密算法
};
#endif

