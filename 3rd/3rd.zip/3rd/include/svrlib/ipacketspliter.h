/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_IPACKETSPLITER_H__
#define __NET_IPACKETSPLITER_H__

namespace net 
{
	class IPacketSpliter {

		public:
			/*
			 * 构造函数
			 */
			IPacketSpliter() {
				m_factory = NULL;
				m_existPacketHeader = true;
				m_bZip = false;
				m_bEncDec = false;
				//m_lastProtoLen = 0;
				m_encDecMethod = ENCDEC_NONE;
				bzero(m_encDecKey,sizeof(m_encDecKey));
			}

			/*
			 * 构造函数
			 */
			IPacketSpliter(IPacketFactory *factory) {
				m_factory = factory;
				m_existPacketHeader = true;
				m_bZip = false;
				m_bEncDec = false;
				//m_lastProtoLen = 0;
			}

			/*
			 * 析构函数
			 */
			virtual ~IPacketSpliter() {}

			/*
			 * 得到包头信息
			 *
			 * @param input  源buffer
			 * @param header 结果header
			 * @return 是否成功
			 */
			virtual bool getPacketInfo(DataBuffer *input, PacketHeader *header, bool *broken) = 0;

			/*
			 * 对包的解码
			 *
			 * @param input
			 * @param header
			 * @return 解码后的数据包
			 */
			virtual Packet *decode(DataBuffer *input, PacketHeader *header) = 0;

			/*
			 * 对Packet的组装
			 *
			 * @param packet 数据包
			 * @param output 组装后的数据流
			 * @return 是否成功
			 */
			virtual bool encode(Packet *packet, DataBuffer *output) = 0;

			/*
			 * 是否有数据包头
			 */
			bool existPacketHeader() {
				return m_existPacketHeader;
			}
			
			/*
			 * 设置是否有包头标志
			 */
			void setExistPacketHeaderFlag(bool flag){
				m_existPacketHeader = flag;
			}

			/*
			 * 设置压缩标志
			 */
			void setZipFlag(bool bZip) {
				m_bZip = bZip;
			}

			/*
			 * 是否压缩
			 */
			bool isZip() { return m_bZip; }

			/*
			 * 设置加解密
			 */
			void setEncDec(bool bEncDec) {
				m_bEncDec = bEncDec;
			}

			/*
			 * 是否要加解密
			 */

			bool isEncDec(){ return m_bEncDec ; }

			/*
			 * 设置最后一个包的长度
			 */
			/*void setLastProtoLen(unsigned int protoLen)
			{
				m_lastProtoLen = protoLen;
			}*/
			/*
			 * 获得最后一个包长度
			 */

			/*unsigned int getLastProtoLen()
			{
				return m_lastProtoLen;
			}*/

			/*
			 * 设置加解密方法
			 */

			void setEncDecMethod(eEncDecMethod method)
			{
				m_encDecMethod = method;
			}

			/*
			 * 获得加解密方法
			 */

			eEncDecMethod getEncDecMethod()
			{
				return m_encDecMethod;
			}

			/*
			 * 设置加密秘钥
			 */

			void setEncDecKey(char * key)
			{
				if (key){
					bcopy(key,m_encDecKey,sizeof(m_encDecKey));
				}
			}

			/*
			 * 返回加密解密秘钥
			 */

			unsigned char * getEncDecKey()
			{
				return m_encDecKey;
			}
		protected:
			IPacketFactory *m_factory;   // 产生packet
			bool m_existPacketHeader;    // 是否有packet header, 如http有自己协议就不需要输出头信息
			bool  m_bZip;				//包是否需要压缩
			bool  m_bEncDec;			//包是否加解密
			//unsigned int m_lastProtoLen;//最后一个发送包的长度		
			eEncDecMethod  m_encDecMethod; //加解密方法
			unsigned char  m_encDecKey[8]; //加解密的秘钥	
	};
}
#endif /*__NET_IPACKETSTREAMER_H__*/
