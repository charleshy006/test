/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_H__
#define __NET_H__

#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include <assert.h>
#include <stdio.h>

#include <list>
#include <queue>
#include <vector>
#include <string>
#include <ext/hash_map>

class DesEcbHelper;
class EncDecHelper;


namespace net 
{
	class DataBuffer;
	
	class Packet;
	class ControlPacket;
	class IPacketFactory;
	class IPacketHandler;
	class IPacketSpliter;
	class PacketQueue;
	
	class PacketSender;
	class Socket;
	class ServerSocket;
	class IOEvent;
	class SocketEvent;
	class EPollSocketEvent;
	class NetIO;
	class IOComponent;
	class TCPAcceptor;
	class TCPComponent;
	class IConnListner;
	class TCPNetIO;
	class CNetConnMgr;
	class ConnectionMgr;
	class PacketProcessorBase;
	class ClientBinPacketSpliter;
	class ClientPacket;
	class IReConnListener;
	class ReconnMgr;
	class MemBuffer;
}
#include "MemBuffer.h"
#include "DesEcb.h"
#include "EncDec.h"
#include "stats.h"
#include  "ThreadMutex.h"
#include "packet.h"
#include "controlpacket.h"
#include "ipacketfactory.h"
#include "databuffer.h"
#include "ipackethandler.h"
#include "ipacketspliter.h"
#include "packetqueue.h"
#include "netutil.h"
#include "socket.h"
#include "serversocket.h"
#include "socketevent.h"
#include "epollsocketevent.h"

#include "netio.h"
#include "tcpnetio.h"

#include "packetsender.h"
#include "iocomponent.h"
#include "tcpacceptor.h"
#include "tcpcomponent.h"
#include "netiothread.h"
#include "Log4cxxHelp.h"
#include  "iconnlistner.h"
#include "clientbinpacketspliter.h"
#include "clientpacket.h"
#include  "connectionmgr.h"
#include "packetprocessorbase.h"
#include "Time.h"
#include "Thread.h"
#include "ireconnlistener.h"
#include "reconnmgr.h"
#include "SvrInfo.h"
#include "clientstringpacketspliter.h"
#include "zlib.h"

extern Log4cxxHelp * Athena::logger;
extern RealTime    g_netlibTime;
#endif

