#ifndef __ATHENA_NEW_H__
#define __ATHENA_NEW_H__
#include <stdlib.h>
#include <stdio.h>
#include <map>
#include "TypesDef.h"

//自定义的
void * operator new(size_t size, const char *file, int line);
void * operator new[](size_t size, const char *file, int line);
void operator delete(void* p, const char* file, int line);
void operator delete[](void* p, const char* file, int line);

//一般形式的
/*void* operator new(std::size_t) throw (std::bad_alloc);
void* operator new[](std::size_t) throw (std::bad_alloc);
void operator delete(void *p) throw();
void operator delete[](void *p) throw();*/

//为了跟以前版本兼容
/*void* operator new(std::size_t, const std::nothrow_t&) throw();
void* operator new[](std::size_t, const std::nothrow_t&) throw();
void operator delete(void*, const std::nothrow_t&) throw();
void operator delete[](void*, const std::nothrow_t&) throw();*/

bool memoryLeaksDump(bool printLeak = true);
void initMemoryLeakCheckSys();

#ifdef _Memmory_Leak_
#define  ATHENA_NEW  new(__FILE__,__LINE__)
#else
#define ATHENA_NEW new
#endif

#endif
