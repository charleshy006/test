/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_PACKET_QUEUE_H__
#define __NET_PACKET_QUEUE_H__

namespace net
{
	class PacketQueue {
		public:
		/*
		 * 构造函数
		 */
		PacketQueue();

		/*
		 * 析构函数
		 */
		~PacketQueue();

		/*
		 * 出链
		 */
		Packet *pop();

		/*
		 * 清空
		 */
		void clear();

		/*
		 * 入链
		 */
		void push(Packet *packet);

		/*
		 * 长度
		 */
		int size();

		/*
		 * 是否为空
		 */
		bool empty();

		/*
		 * 移动到其他队列上
		 */
		void moveTo(PacketQueue *destQueue);

		/*
		 * 取到packet list
		 */
		Packet *getPacketList();

		/*
		 *取得队列头指针
		 */
		Packet *head()
		{
			return m_head;
		}
		/*
		 *取得队列尾指针
		 */
		Packet* tail()
		{
			return m_tail;
		}
		protected:
		Packet *m_head;  // 链头
		Packet *m_tail;  // 链尾
		int m_size;      // 元素数量
	};

}

#endif

