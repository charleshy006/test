#ifndef __ELEMENT_H__
#define  __ELEMENT_H__
#include "TypesDef.h"
#include "Noncopyable.h"
#include "CommonMicro.h"

class Element : private Noncopyable
{
	private:
  		UINT32              m_id;    
    	UINT64              m_tempid;    
    	char                m_name[MAX_NAMESIZE + 1]; 
	public:
    	Element() : m_id(0), m_tempid(0L)
    	{	   
	        bzero(m_name, sizeof(m_name));
	    }   
    	virtual ~Element(){}
    
    	inline UINT32 getID() const { return m_id; }
    	inline UINT64 getTempID() const { return m_tempid; }
    	inline char* getName() { return m_name; }
    	inline void setID(const UINT32 _id) { m_id = _id; }
    	inline void setTempID(const UINT64  _tempid) { m_tempid = _tempid; }
    	inline void setName(const char* _name) { strncpy(m_name, _name, MAX_NAMESIZE); }
};

template <typename T>
struct execElement {
    virtual ~execElement() {}; 
    virtual bool exec(T * e) = 0;
};

#endif
