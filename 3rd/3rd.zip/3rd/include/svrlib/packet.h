/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */


#ifndef __NET_PACKET_H__
#define __NET_PACKET_H__

namespace net
{
	#define unzipBufferLen(zipSize)    ((zipSize) * 120 / 100 + 12)
	const unsigned short PH_FLAG_ZIP = 1 << 14;		//压缩标志
	const unsigned short PH_FLAG_ENC = 1 << 15;		//加密标志
	const unsigned int   PH_FLAG_ZIP_MIN    = 32;   //zip最小值
	//#define MAX_DATASIZE 65530 

	class PacketHeader 
	{
		public:
			unsigned short 	m_dataLen;           // 数据包body长度(除头信息外)
			unsigned short  m_flag;				 // 报的标志
			unsigned char 	m_modID;			 // 模块ID
			unsigned char   m_funID;			 // 模块的功能ID
			unsigned int    m_sendTime;			 // 发送协议的ID

			PacketHeader()
			{
				m_dataLen = 0;
				m_flag = 0;
				m_modID = 0;
				m_funID = 0;
				m_sendTime = 0;
			}
	};

	class Packet
	{
		friend class PacketQueue;

		public:
		/*
		 * 构造函数, 传包类型
		 */
		Packet();

		/*
		 * 析构函数
		 */
		virtual ~Packet();

		/*
		 * 得到数据包header info
		 */
		PacketHeader *getPacketHeader() {
			return &m_packetHeader;
		}

		/*
		 * 设置数据包header info
		 */
		void setPacketHeader(PacketHeader *header) {
			if (header) {
				memcpy(&m_packetHeader, header, sizeof(PacketHeader));
			}
		}

		/*
		 * 释放自己
		 */
		virtual void free() {
			delete this;
		}

		/*
		 * 是否数据包
		 */
		virtual bool isRegularPacket() {
			return true;
		}

		/*
		 * 组装
		 *
		 * @param output: 目标buffer
		 * @return 是否成功
		 */
		virtual bool encode(DataBuffer *output,bool bZip) = 0;

		/*
		 * 解开
		 *
		 * @param input: 源buffer
		 * @param header: 数据包header
		 * @return 是否成功
		 */
		virtual bool decode(DataBuffer *input, PacketHeader *header,bool bZip) = 0;

		/*
		 * 得到next
		 */
		Packet *getNext() const {
			return m_next;
		}

		protected:
		PacketHeader m_packetHeader; // 数据包的头信息
		Packet *m_next;              // 用在packetqueue链表
	};
}
#endif /*__NET_PACKET_H__*/
