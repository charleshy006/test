#ifndef __HTTP_REQUEST_H__
#define __HTTP_REQUEST_H__
#include "TypesDef.h"
#include <vector>
#include <string>

class CHttpClient;
class CHttpResponse;
typedef void (* SEL_HttpResponse)(CHttpClient* client, CHttpResponse* response);
#define httpresponse_selector(_SELECTOR) (cocos2d::extension::SEL_HttpResponse)(&_SELECTOR)

class CHttpRequest
{
public:
    //http请求的类型
	typedef enum
    {
        kHttpGet,
        kHttpPost,
        kHttpPut,
        kHttpDelete,
        kHttpUnkown,
    } HttpRequestType;
   
	//构造函数
    CHttpRequest()
    {
        m_requestType = kHttpUnkown;
        m_url.clear();
        m_requestData.clear();
        m_tag.clear();
        m_pSelector = NULL;
        m_pUserData = NULL;
    };
    
    //析构函数
	virtual ~CHttpRequest()
    {
    };
    //设置请求类型    
    inline void setRequestType(HttpRequestType type)
    {
        m_requestType = type;
    };
    //请求类型
	inline HttpRequestType getRequestType()
    {
        return m_requestType;
    };
   	//设置请求地址 
    inline void setUrl(const char* url)
    {
        m_url = url;
    };
	//获得请求地址
    inline const char* getUrl()
    {
        return m_url.c_str();
    };
	//设置请求数据
    inline void setRequestData(const char* buffer, unsigned int len)
    {
        m_requestData.assign(buffer, buffer + len);
    };
	//获得请求数据
    inline char* getRequestData()
    {
        return &(m_requestData.front());
    }
    //请求数据
	inline int getRequestDataSize()
    {
        return m_requestData.size();
    }
	//设置请求标志
    inline void setTag(const char* tag)
    {
        m_tag = tag;
    };
	//获得请求标志
	inline const char* getTag()
    {
        return m_tag.c_str();
    };
   	//设置而外数据 
    inline void setUserData(void* pUserData)
    {
        m_pUserData = pUserData;
    };
	//获得额外数据
    inline void* getUserData()
    {
        return m_pUserData;
    };
	//设置回调对象和方法
    inline void setResponseCallback(SEL_HttpResponse pSelector)
    {
        m_pSelector = pSelector;
    }
	//返回回调函数
	inline SEL_HttpResponse  getSelector()
	{
		return m_pSelector;
	}
    //设置请求头
	inline void setHeaders(std::vector<std::string> pHeaders)
   	{
   		m_headers=pHeaders;
   	}
	//获得请求的数据
   	inline std::vector<std::string> getHeaders()
   	{
   		return m_headers;
   	}
protected:
    HttpRequestType             m_requestType;    // http请求类型
    std::string                 m_url;            // 请求的地址
    std::vector<char>           m_requestData;    // post提交的数据
    std::string                 m_tag;            // 用来标志不同的请求 
    SEL_HttpResponse            m_pSelector;      // 回调函数
    void*                       m_pUserData;      // 而外的数据
    std::vector<std::string>    m_headers;		  // 请求的头数据 
};

#endif //__HTTP_REQUEST_H__
