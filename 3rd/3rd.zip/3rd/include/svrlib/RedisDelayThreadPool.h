#ifndef __H_REDISDELAYTHREADPOOL_H__
#define __H_REDISDELAYTHREADPOOL_H__
#include "RedisDelayThread.h"
#include <vector>
#include "RedisOperation.h"
#include "Singleton.h"

class xRedisClient;

class CRedisDelayThreadPool
{
	public :
		USE_SINGLETON_NEW(CRedisDelayThreadPool);
	public :
		static const UINT16 MAX_THREAD_NUM = 1;
	private :
		CRedisDelayThreadPool(){}
	public :
		static CRedisDelayThreadPool & getSingleton()
		{
			return THE_SINGLETON::Instance();
		}
		static void destroyMe()
		{
			THE_SINGLETON::destroy();
		}
		~CRedisDelayThreadPool();
		bool init(xRedisClient *pDB);
		void delay(CRedisOperation * sqlOp);
		void processAllCB();
	private :
		std::vector<CRedisDelayThread *> m_threadPool;
};

#endif
