/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_IPACKET_FACTORY_H__
#define __NET_IPACKET_FACTORY_H__

namespace net
{
	class IPacketFactory 
	{
		public:
			virtual ~IPacketFactory() {};
			virtual Packet *createPacket(int len) = 0;
	};
}

#endif /*__NET_IPACKET_FACTORY_H__*/
