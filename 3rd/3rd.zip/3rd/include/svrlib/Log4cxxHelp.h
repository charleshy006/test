#ifndef __LOG4CXXHELP_H__
#define __LOG4CXXHELP_H__
#include <log4cxx/logger.h>
#include <log4cxx/dailyrollingfileappender.h>
#include <log4cxx/helpers/dateformat.h>
#include "ThreadMutex.h"
#include "TypesDef.h"

class Log4cxxHelp
{
private:
	log4cxx::LoggerPtr	m_plogger;
	log4cxx::LogString m_loggerName;
	char m_message[MSGBUF_MAX];
	Mutex m_mutex;
public:
	Log4cxxHelp(const log4cxx::LogString& name = "Athena");
	virtual ~Log4cxxHelp();
	//获取Log4cxxHelp的名字，它出现在每条日志信息中
	const log4cxx::LogString getName();
	//移除控制台输出LOG
	void removeConsoleLog();
	//加一个本地文件Log输出
	//param file 要输出的文件名，Log4cxxHelp会自动的添加时间后缀
	bool addLocalFileLog(const log4cxx::LogString& file);
	//写fatal程序日志
	void fatal(const char* pattern, ...);
	//写error程序日志
	void error(const char* pattern, ...);
	//写warn程序日志
	void warn(const char* pattern, ...);
	//写info程序日志
	void info(const char* pattern, ...);
	//写debug程序日志
	void debug(const char* pattern, ...);
	//写trace游戏日志
	void trace(const char* pattern, ...);
};

namespace Athena {
	extern Log4cxxHelp* logger;
};
#endif

