#ifndef __H_RECONNMGR_H__
#define __H_RECONNMGR_H__
#include "net.h"
#include "TypesDef.h"

namespace net
{
	class ReconnMgr  : public IReConnListener , public PacketSender
	{
		public :
			//构造
			ReconnMgr();
			//析构
			~ReconnMgr();
			//添加连接信息
			void addConnectSvrInfo(TCPComponent * pConn,SvrInfo & svrInfo);
			//连接成功
			virtual void onConnectSvrSucess(TCPComponent  *pTcpCom);
			//端口连接
			virtual void onDisConnect(TCPComponent  *pTcpCom);
			//根据ID广播
			template <class T>
			bool broadcastByID(UINT16 svrID,const T & cmd);
			//给所有连接广播
			template <class T>
			bool broadcastProto2All(const T & cmd);
			//连接服务器
			virtual bool sendMyInfo(TCPComponent  *pTcpCom) = 0;
		private :
			std::vector<TCPComponent * > m_connectSvrInfoVec;
	};
	
	template <class T>
	bool ReconnMgr::broadcastByID(UINT16 svrID,const T & cmd)
	{
		for (UINT16 i = 0;i < m_connectSvrInfoVec.size();++i){
			if (!m_connectSvrInfoVec[i]){
				continue;
			}
			SvrInfo & svrInfo = m_connectSvrInfoVec[i]->getSvrInfo();
			if (svrInfo.m_svrID == svrID){
				 std::string retStr;
				 cmd.SerializeToString(&retStr);
				 return sendClientProto(m_connectSvrInfoVec[i],cmd.ModID,cmd.FunID,retStr.c_str(),retStr.size());
			}
		}
		return false;
	}
	
	template <class T>
	bool ReconnMgr::broadcastProto2All(const T & cmd)
	{
		for (UINT16 i = 0;i < m_connectSvrInfoVec.size();++i){
			if (m_connectSvrInfoVec[i]){
				std::string retStr;
				cmd.SerializeToString(&retStr);
				sendClientProto(m_connectSvrInfoVec[i],cmd.ModID,cmd.FunID,retStr.c_str(),retStr.size());
			}
		}
		return true;
	}
};
#endif
