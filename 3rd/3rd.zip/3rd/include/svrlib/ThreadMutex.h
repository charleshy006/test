#ifndef __MUTEX_H__
#define __MUTEX_H__
#include "Noncopyable.h"
#include <pthread.h>

class Mutex : private  Noncopyable
{
	friend class Cond;
private:
	pthread_mutex_t	m_mutex;
public:
	Mutex(int kind = PTHREAD_MUTEX_FAST_NP);
	virtual ~Mutex();
	void lock();
	void unlock();
};

class MutexGuard : private  Noncopyable
{
private:
	Mutex& m_mutex;
public:
	MutexGuard(Mutex& m);
	~MutexGuard();
};

class Cond : private  Noncopyable
{
private:
	pthread_cond_t m_cond;	//系统条件变量
public:
	Cond();
	virtual ~Cond();
	//广播信号给所有等待这个条件变量的线程
	void broadcast();
	//发送信号给所有等待这个条件变量的线程
	void signal();
	//等待特定的条件变量满足
	void wait(Mutex& mutex);
};
#endif /*MUTEX_H_*/
