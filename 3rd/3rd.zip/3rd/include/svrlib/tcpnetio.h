/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_TCPCONNECTION_H__
#define __NET_TCPCONNECTION_H__

namespace net 
{
	class TCPNetIO : public NetIO 
	{
		public:
			/*
			 * 构造函数
			 */
			TCPNetIO(Socket *socket, IPacketSpliter * spliter, IPacketHandler *serverAdapter);

			/*
			 * 析构函数
			 */
			~TCPNetIO();

			/*
			 * 写出数据
			 *
			 * @return 是否成功
			 */
			bool writeData();

			/*
			 * 读入数据
			 *
			 * @return 读入数据
			 */
			bool readData();

			/*
			 * 设置写完是否主动关闭
			 */
			void setWriteFinishClose(bool v) {
				m_writeFinishClose = v;
			}

			/*
			 * 清空output的buffer
			 */
			void clearOutputBuffer() {
				m_output.clear();
			}

			/*
			 * clear input buffer
			 */
			void clearInputBuffer() {
				m_input.clear();
			}

			/**
			 * 发送setDisconnState
			 */
			void setDisconnState();

		private:
			DataBuffer m_output;      // 输出的buffer
			DataBuffer m_inputRaw;	  // 读入的原始buffer
			DataBuffer m_input;       // 读入的buffer
			PacketHeader m_packetHeader; // 读入的packet header
			bool m_gotHeader;            // packet header已经取过
			bool m_writeFinishClose;     // 写完断开
			EncDecHelper  m_encDecHelper;		//加密辅助对象
	};

}
#endif /*__NET_TCPCONNECTION_H__*/
