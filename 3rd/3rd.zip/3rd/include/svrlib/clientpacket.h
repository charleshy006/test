/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __H_CLIENT_PACKET_H__
#define __H_CLIENT_PACKET_H__
#include "net.h"
#include "TypesDef.h"
#include  "tcpcomponent.h"

namespace net 
{
	class ClientPacket : public Packet
	{
		public:
			//通用包
			ClientPacket(UINT32 len);
			//析构
			~ClientPacket();
			//序列化包
			bool encode(DataBuffer *output,bool bZip);
			//反序列化
			bool decode(DataBuffer *input, PacketHeader *header,bool bZip);
			//获得模块ID
			byte getModID() { return m_packetHeader.m_modID ; }
			//获得功能号
			byte getFunID() { return m_packetHeader.m_funID ; }
			//设置数据
			void setData(const void * pData);
			//获得数据
			char * getData() { return m_data ;}
			//获得长度
			UINT32 getLen() { return m_len ;}
		private :
			char  * m_data;						//协议内容
			UINT32 m_len;						//协议长度
		public :
			TCPComponent * m_pComponent;
	};

	class ClientPacketFactory : public IPacketFactory
	{
		public:
			Packet *createPacket(int len)
			{
				return new ClientPacket(len);
			}
	};

};
#endif
