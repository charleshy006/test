#ifndef __H_KVPAIR_H__
#define __H_KVPAIR_H__
#include "TypesDef.h"
#include <string>
#include <ext/hash_map>

class KVPair
{
protected:
	typedef __gnu_cxx::hash_map<std::string, std::string, my_hash<std::string>, my_key_equal<std::string> > kvpair_hashtype;
	typedef __gnu_cxx::hash_map<std::string, UINT32, my_hash<std::string>, my_key_equal<std::string> > kvpair_hashtype_num;
	kvpair_hashtype m_kvpairs;
	kvpair_hashtype_num m_kvpairs_num;
public:
	KVPair();
	virtual ~KVPair();
	const std::string& getStr(const std::string& key);
	inline UINT32 getNum(const std::string& key);
	void setProperty(const std::string& key, const std::string& value);
	std::string& operator[] (const std::string& key);
};
#endif
