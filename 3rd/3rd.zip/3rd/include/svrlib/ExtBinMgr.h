#ifndef __EXT_BIN_MGR__
#define __EXT_BIN_MGR__
#include "TypesDef.h"
#include <vector>

#pragma pack(1)
struct stSaveItem
{
	UINT16 	m_scheme;
	UINT16  m_count;
	byte    m_data[0];
	stSaveItem()
	{
		m_scheme = 0;
		m_count = 0;
	}
	
	UINT32 getSize()
	{
		return sizeof(stSaveItem) + m_count;
	}
};
#pragma pack()


class ExtBinMgr
{
	public :
		ExtBinMgr()
		{}

		virtual ~ExtBinMgr()
		{}
		//是否需要保存
		virtual bool isNeedSave(byte s);
		//获得保存数据大小
		virtual UINT32 getSaveSize(byte s);
		//执行保存操作
		virtual UINT32 doSaveAction(byte* data, byte s, UINT32 dataSize);
		//执行加载操作
		virtual UINT32 doRestorAction(byte* data);
		//保存所有扩展数据
		//param : data 2进制的最开始位置
		//param : spaceSize 空间大小
		//return : 保存的2进制数据
		UINT32 saveAll(byte * data,UINT32 spaceSize);
		//加载所有扩展2进制
		bool loadAll(byte * data);
	protected :
		std::vector<byte>  m_scheme;
};
#endif
