#ifndef   __H_NETIOTHREAD_H__
#define __H_NETIOTHREAD_H__
#include "net.h"
#include "Thread.h"
#include <vector>

namespace net {
	class CNetConnMgr;
	
	class CWorkerThreadBase : public Thread
	{
		public :
			/*
			 * 构造函数
			 */
			CWorkerThreadBase(CNetConnMgr *);

			/*
			 * 析构函数
			 */
			virtual ~CWorkerThreadBase();

			/*
			 * 删除一个IOComponent
			 * @IOComponent 参数
			 *
			 */
			virtual void removeComponent(IOComponent *ioc) {}
			
			/*
			 * 加入到iocomponents中
			 *
			 * @param  ioc: IO组件
			 * @param  readOn: 初始化把读事件打开
			 * @param  writeOn: 初始化把写事件打开
			 */
			virtual void addComponent(IOComponent *ioc, bool readOn, bool writeOn) {}

			/*  
			 * 等待线程完全退出。
			 *
			 * @return 是否成功, true - 成功, false - 失败
			 */
			bool wait();

			/*
			 * 释放变量
			 */
			void destroy();
			
			/*
			 * 返回当前连接数量
			 */
			unsigned int  size() { return m_iocListCount ;}
		protected :
			EPollSocketEvent m_socketEvent;      		//读写socket事件
			Mutex m_iocsMutex;							//互斥锁
			IOComponent *m_iocListHead, *m_iocListTail; //IOComponent集合
			unsigned int m_iocListCount;				//列表数量 
			CNetConnMgr  *m_pNetThreadMgr;             //线程管理
	};

	class CListenThread : public CWorkerThreadBase
	{
		public:
			/*
			 * 构造函数
			 */
			CListenThread(CNetConnMgr *);
				
			/*
			 * 析构函数
			 */
			~CListenThread();

			/*
			 * 线程回调
			 * @ thread 参数类
			 * @ arg   参数
			 */
			void run();
			
			/*
			 * 加入到iocomponents中
			 *
			 * @param  ioc: IO组件
			 * @param  readOn: 初始化把读事件打开
			 * @param  writeOn: 初始化把写事件打开
			 */
			void addComponent(IOComponent *ioc, bool readOn, bool writeOn);

			/*
			 * 删除一个IOComponent
			 * @IOComponent 参数
			 *
			 */
			virtual void removeComponent(IOComponent *ioc);
	};

	class CNetIOThread : public CWorkerThreadBase
	{
		public 	:
			/**
			 * 构造函数
			 */
			CNetIOThread(CNetConnMgr  * );
			/*
			 * 析构函数
			 */
			~CNetIOThread();
			
			/*
			 * 线程回调
			 * @ thread 参数类
			 * @ arg   参数
			 */
			void run();
			
			/*
			 * 删除一个IOComponent
			 * @IOComponent 参数
			 *
			 */
			void removeComponent(IOComponent *ioc);
			
			/*
			 * 加入到iocomponents中
			 *
			 * @param  ioc: IO组件
			 * @param  readOn: 初始化把读事件打开
			 * @param  writeOn: 初始化把写事件打开
			 */
			void addComponent(IOComponent *ioc, bool readOn, bool writeOn);
	};
	
	class CFreeIOComponentThread  : public CWorkerThreadBase
	{
		public :
			/*
			 * 构造函数
			 */
			CFreeIOComponentThread(CNetConnMgr  *pNetThreadMgr);

			/*
			 * 析构函数
			 */
			~CFreeIOComponentThread();
			
			/*
			 * 加入到iocomponents中
			 *
			 * @param  ioc: IO组件
			 */
			void addComponent(IOComponent *ioc);

			/*
			 * 线程回调
			 * @ thread 参数类
			 * @ arg   参数
			 */
			void run();
	};

	class CNetConnMgr
	{
		private :
			CListenThread   * m_listnerThread;				//监听线程
			std::vector<CNetIOThread *>	m_netIOThreads;		//工作线程
			IConnListner   *m_pConnListner;                 //连接管理
			unsigned int  m_maxIOComponent;					//最大连接数量
			CFreeIOComponentThread  *m_freeThread;			//释放线程
			bool  m_stop;									//已经停止
		public :
			/*
			 * 构造函数
			 */
			CNetConnMgr(IConnListner *pConnListner,unsigned int maxIOComponet = MAX_SOCKET_EVENTS);

			/*
			 * 析构函数
			 */
			~CNetConnMgr();
			
			/*
			 * 进行初始化
			 *@return true 成功,false 失败
			 */
			bool init(unsigned int maxIOComponet = MAX_SOCKET_EVENTS);
			
			/*
			 * 线程结束
			 */
			void final();
			
			/*
			 * 添加到监听线程
			 */
			bool add2Listner(IOComponent *ioc);

			/*
			 * 增加一个io控制到工作线程
			 * @para ioc
			 * @return true 成功,fasle失败
			 */
			bool addComponent(IOComponent *ioc);

			/*
			 * 回收连接
			 * @param ioc 要回收的连接
			 */
			bool  recycle(IOComponent *ioc);

			/*  
			 * 停止，停掉读所有线程，及销毁。
			 * @return 是否成功, true - 成功, false - 失败。
			 */
			bool stop();

			/*
			 *是否stop
			 */
			bool getStop() { return m_stop ;}

			/*
			 * 起一个监听端口。
			 *
			 * @param spec: 格式 [upd|tcp]:ip:port
			 * @param spliter: 数据包的双向流，用packet创建，解包，组包。
			 * @param serverAdapter: 用在服务器端，包来时候创建时回调时用
			 * @return IO组件一个对象的指针
			 */
			IOComponent *listen(const char *spec,IPacketSpliter * spliter, IPacketHandler *serverAdapter);

			/*
			 * 创建一个NetIO，连接到指定的地址，并加入到Socket的监听事件中。
			 *
			 * @param spec: 格式 [upd|tcp]:ip:port
			 * @param spliter: 数据包的双向流，用packet创建，解包，组包。
			 * @param autoReconn: 是否重连
			 * @return  返回一个Connectoion对象指针
			 */
			IOComponent *connect(const char *spec,IPacketSpliter * spliter, bool autoReconn = false,IReConnListener  * pReconnListener = NULL);

			/*
			 * 主动断开,不等发送数据完就断开
			 */
			bool disconnect(NetIO *conn);

			/*
			 * 等待发送完数据再断开
			 */
			void writeFinishClose(NetIO * pConn);
		private:
			/*
			 * 把[upd|tcp]:ip:port分开放在args中
			 *
			 * @param src: 源格式
			 * @param args: 目标数组
			 * @param   cnt: 数组中最大个数
			 * @return  返回的数组中个数
			 */
			int parseAddr(char *src, char **args, int cnt);
	};
};
#endif
