#ifndef   __H_PROTOMSG_HANDLE_H__
#define __H_PROTOMSG_HANDLE_H__
#include "TypesDef.h"
#include "net.h"
#include <google/protobuf/message.h>
#include <map>

using namespace net;

class ProtoMsgHandleBase
{
public :
	//构造
	ProtoMsgHandleBase(){}
	//析构
	virtual ~ProtoMsgHandleBase(){}
	//处理网络协议
	virtual bool handle(TCPComponent * pCom,const char * pData,const UINT32 & cmdLen,UINT8 funID) = 0;
};

template <class T,class P = TCPComponent>
class ProtoMsgHandle
{
public :
	//构造
	ProtoMsgHandle(){}
	//析构
	virtual ~ProtoMsgHandle(){}
public :
	//处理网络协议
	virtual bool handle(P * pCom,const char * pData,const UINT32 & cmdLen,UINT8 funID);
protected :
	typedef void (T::*msg_handle)(P * pCom,google::protobuf::Message *);
protected :
	template <class MSGTYPE>
	void registerHandle(void (T::*callback)(P * pComm,MSGTYPE *))
	{
		UINT8 funID = MSGTYPE::FunID;
		m_callbacks[funID] = (msg_handle)callback;
		const google::protobuf::Descriptor * pDes = MSGTYPE::descriptor();
		if (pDes) {
			m_descriptors[MSGTYPE::FunID] = pDes;
		}
	}
protected :
	std::map<UINT8,msg_handle>  m_callbacks;
	std::map<UINT8,const google::protobuf::Descriptor *> m_descriptors;
};

template <class T,class P>
bool ProtoMsgHandle<T,P>::handle(P * pCom,const char * pData,const UINT32 & cmdLen,UINT8 funID)
{
	if (!pData || cmdLen <= 0) {
		return false;
	}

	msg_handle  pCb = m_callbacks[funID];
	const google::protobuf::Descriptor * pDesc  = m_descriptors[funID];

	if (!pCb || !pDesc) {
		return false;
	}

	const google::protobuf::Message * prototype = google::protobuf::MessageFactory::generated_factory()->GetPrototype(pDesc);
	if (prototype == NULL) {
		return false;
	}

	google::protobuf::Message * msg = prototype->New();
	bool ret = msg->ParseFromArray(pData,cmdLen);
	if (ret) {
		(((T*)this)->*pCb)(pCom,msg);
		delete msg;
		return true;
	}
	return false;
}

#endif
