#ifndef __H_UTIL_FUNCTION_H__
#define __H_UTIL_FUNCTION_H__
#include <vector>
#include <map>
#include <string>
#include "tinyxml/tinyxml.h"
#include "TypesDef.h"
#include "SvrInfo.h"

//答应命令行帮助
void g_printUsage(char *prog_name);
//解析命令行
void g_parseCmdLine(int argc, char *const argv[]);
//获得服务器信息列表
bool g_initSvrList(std::map<UINT16,SvrInfo> & serverCtn);
//按分割符号来分割字符串
void g_stringtok(std::vector<std::string>& result, std::string const &in, const char* const sep = "\t\n",const int deep = 0);
//获得几分之几概率
bool g_selectByOdds(const UINT32 upNum, const UINT32 downNum);
//获得百分之几概率
bool g_selectByPercent(const UINT32 percent);
//获得千分之几概率 
bool g_selectByThound(const UINT32 percent);
//获得万分之几的概率
bool g_selectByTenThound(const UINT32 percent);
//获得min ,max之间的随机数
int g_randBetween(INT32 min, INT32 max);
//根据一个数据获得概率
int g_selectByVec(std::vector<UINT32> & vec,UINT32 maxVal = 1000);
//根据一个map获得概率
int g_selectByMap(std::map<UINT32,UINT32> &kvMap,UINT32 maxVal = 1000);
//字符集转换,返回长度,-1表示错误
bool g_charsetConvert(const char * fromCharset,const char * destCharset,const char * inBuf,const UINT32 inLen,char * outBuf,UINT32 & outLen);
//初始化
bool g_initCommon(int argc, char** argv,bool initAppCfg = true);
//是否同一天,两个格林威治时间
bool g_isTheSameDay(UINT32 time1,UINT32 time2);
//是否同一周,两个格林威治时间
bool g_isTheSameWeek(UINT32 time1,UINT32 time2);
//是否同一个月,连个格林威治时间
bool g_isTheSameMonth(UINT32 time1,UINT32 time2);
//列出某个目录下所有文件
bool g_listDirsFile(std::string path,const std::string extendName,std::vector<std::string> & result);
//base64加密
const std::string g_encode64( const std::string& input );
//base64解密
const std::string g_decode64( const std::string& input );
//UTC 时间转化成字符表示
const std::string g_utc2StringFormat(time_t utcTime);
//UTC 时间转化成日期
const std::string g_utc2StringDate(time_t utcTime,const char * szFormat = "%Y-%m-%d");
//时间格式转化程utc时间
const UINT32 g_stringDate2Utc(const char * szTime,const char * szFormat = "%Y-%m-%d %H:%M:%S");
//是否闰年
bool  g_isLeapYear(UINT32 year);
//获得一年中的第几天
UINT32 g_chg2YearDay(UINT32 year,UINT32 month,UINT32 day);
//相差的天数
INT32 g_dayDiff(UINT32 year2,UINT32 month2,UINT32 day2,UINT32 year1,UINT32 month1,UINT32 day1);
//整数转换成string
std::string g_int2string(UINT32 num);
//浮点数转化string
std::string g_float2string(float num);
//执行shell命令行
std::string s_exeShellCommand(const char * szCommand);
//获得一天中经过的秒数
UINT32 g_getSecOfDay(UINT32 cur);

namespace HttpUtility
{

	typedef unsigned char BYTE;

	inline BYTE toHex(const BYTE &x)
	{
		return x > 9 ? x -10 + 'A': x + '0';
	}

	inline BYTE fromHex(const BYTE &x)
	{
		return isdigit(x) ? x-'0' : x-'A'+10;
	}

	inline std::string URLEncode(const std::string &sIn)
	{
		std::string sOut;
		for( size_t ix = 0; ix < sIn.size(); ix++ )
		{      
			BYTE buf[4];
			memset( buf, 0, 4 );
			if( isalnum( (BYTE)sIn[ix] ) )
			{      
				buf[0] = sIn[ix];
			}           
			else
			{
				buf[0] = '%';
				buf[1] = toHex( (BYTE)sIn[ix] >> 4 );
				buf[2] = toHex( (BYTE)sIn[ix] % 16);
			}
			sOut += (char *)buf;
		}
		return sOut;
	};

	inline std::string URLDecode(const std::string &sIn)
	{
		std::string sOut;
		for( size_t ix = 0; ix < sIn.size(); ix++ )
		{
			BYTE ch = 0;
			if(sIn[ix]=='%')
			{
				ch = (fromHex(sIn[ix+1])<<4);
				ch |= fromHex(sIn[ix+2]);
				ix += 2;
			}
			else if(sIn[ix] == '+')
			{
				ch = ' ';
			}
			else
			{
				ch = sIn[ix];
			}
			sOut += (char)ch;
		}
		return sOut;
	}
}
#endif
