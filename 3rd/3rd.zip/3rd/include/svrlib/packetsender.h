#ifndef __H_PACKET_SENDER_H__
#define __H_PACKET_SENDER_H__

namespace net
{
	class PacketSender
	{
		public :
			//构造
			PacketSender();
			//析构
			~PacketSender();
			//发送客户端协议
			bool sendClientProto(TCPComponent *pConn,UINT8 modID,UINT8 funID,const void *pData,const UINT32 cmdLen);
	};
};
#endif
