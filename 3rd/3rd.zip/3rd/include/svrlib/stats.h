/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_STATS_H__
#define __NET_STATS_H__

namespace net 
{
	class StatCounter {
		public:
			StatCounter();
			~StatCounter();
			void log();
			void clear();

		public:
			uint64_t m_packetReadCnt;  // # packets read
			uint64_t m_packetWriteCnt; // # packets written
			uint64_t m_dataReadCnt;    // # bytes read
			uint64_t m_dataWriteCnt;   // # bytes written

		public:
			static StatCounter _gStatCounter; // 全局

	};

#define NET_GLOBAL_STAT net::StatCounter::_gStatCounter
#define NET_COUNT_PACKET_READ(i) { NET_GLOBAL_STAT.m_packetReadCnt += (i);}
#define NET_COUNT_PACKET_WRITE(i) { NET_GLOBAL_STAT.m_packetWriteCnt += (i);}
#define NET_COUNT_DATA_READ(i) { NET_GLOBAL_STAT.m_dataReadCnt += (i);}
#define NET_COUNT_DATA_WRITE(i) { NET_GLOBAL_STAT.m_dataWriteCnt += (i);}

}

#endif

