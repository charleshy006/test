#ifndef __TIME_H__
#define __TIME_H__

#include <time.h>
#include <sys/time.h>
#include <sstream>
#include "TypesDef.h"

class RealTime
{
private:
	UINT64	m_msecs;		//真实时间换算为毫秒
public:
	RealTime(const int delay = 0);
	RealTime(const RealTime& rt);
	~RealTime();
	//获得当前时间
	UINT64 now();
	//获得秒
	UINT32 sec() const;
	//获得毫秒
	UINT64 msecs() const;
	//增加延迟
	void addDelay(int delay);
	//重载等于号
	RealTime& operator = (const RealTime& rt);
	//距离现在已经经过了多少时间
	UINT64 elapse(const RealTime& rt) const; 
	//距离现在已经经过了多少时间
	UINT64 elapse() const;
public:
	static INT32	m_timezone;								//区时间
	static const std::string& getLocalTZ();					//获得时区
	static void getLocalTime(tm& tv, time_t timeValue);		//获得当前时间
};

//计时器
class Timer
{
private:
	INT32		m_interval;				//定时间隔
	RealTime	m_timer;
public:
	Timer(const INT32 interval, const INT32 delay = 0) ;
	virtual ~Timer();
	bool operator () (const RealTime& current);
};
#endif

