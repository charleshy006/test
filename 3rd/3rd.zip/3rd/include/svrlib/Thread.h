#ifndef __THREAD_H__
#define __THREAD_H__

#include <pthread.h>
#include <unistd.h>
#include <string>
#include "Noncopyable.h"
#include "ThreadMutex.h"

class Thread : private Noncopyable
{
protected:
	std::string		m_threadName;				//线程名字
	Mutex			m_mutex;					//互斥
	Cond			m_cond;						//条件
	volatile bool	m_alive;					//是否存活
	volatile bool	m_final;					//是否结束
	pthread_t		m_threadID;					//线程ID
	bool			m_joinable;					//是否分分离

public:
	Thread(const std::string& name = std::string("Thread"), const bool joinable = true);
	virtual ~Thread();
	//是否是join类型线程
	const bool isJoinable() const;
	//线程是否还存活
	const bool isAlive() const;
	//线程是否结束
	const bool isFinal() const;
	static void* threadCB(void* arg);
	//开始线程
	bool start();
	//join线程
	void join();
	//结束线程
	virtual void final();
	virtual void run() = 0;
};
#endif
