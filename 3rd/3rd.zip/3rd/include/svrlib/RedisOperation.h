#ifndef __REDISOPERATION_H__
#define __REDISOPERATION_H__
#include "Callback.h"
#include <string>

class xRedisClient;

class CRedisOperation
{ 
	public:  
		CRedisOperation()
		{
		}
		virtual void execute(xRedisClient *pRedisDB) = 0; 
		virtual ~CRedisOperation() {}
		void setKey(const std::string & strKey)
		{
			m_strKey = strKey;
		}
		virtual void processCB() = 0;
	protected  :
		std::string m_strKey;
};

class CQueryRedisOperation :public CRedisOperation
{
	public :
		CQueryRedisOperation(Athena::IRedisQueryCallback * pCB):m_pCB(pCB),m_pBlobData(NULL)
		{}
		~CQueryRedisOperation();
		virtual void execute(xRedisClient *pRedisDB);
		virtual void processCB();
	protected :
		Athena::IRedisQueryCallback	 * m_pCB;
		std::string * m_pBlobData;
};

class CCUDRedisOperation :public CRedisOperation
{
	public :
		CCUDRedisOperation(Athena::ICUDRedisCallBack * callback) : m_pCB(callback)
		{}
		~CCUDRedisOperation();
		virtual void execute(xRedisClient *pRedisDB);
		virtual void processCB();
	protected :
		Athena::ICUDRedisCallBack * m_pCB;
		std::string m_strValue;
};
#endif
