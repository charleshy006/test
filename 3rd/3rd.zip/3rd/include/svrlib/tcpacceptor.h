/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_TCPACCEPTOR_H__
#define __NET_TCPACCEPTOR_H__

namespace net 
{
	class TCPAcceptor : public IOComponent {

		public:
			/**
			 * 构造函
			 *
			 * @param  owner:    运输层对象
			 * @param  socket:   Socket对象
			 * @param  spliter:   数据包的双向流，用packet创建，解包，组包。
			 * @param  serverAdapter:  用在服务器端,处理包时候回调
			 */
			TCPAcceptor(CNetConnMgr *owner, Socket *socket,
					IPacketSpliter * spliter, IPacketHandler *serverAdapter);

			/*
			 * 初始化
			 *
			 * @return 是否成功
			 */
			bool init(bool isServer = false,IReConnListener  * pReconnListener = NULL);

			/**
			 * 当有数据可读时被io线程调用
			 *
			 * @return 是否成功, true - 成功, false - 失败。
			 */
			bool handleReadEvent();

			/**
			 * 在accept中没有写事件
			 */
			bool handleWriteEvent() {
				return true;
			}

			/*
			 * 超时检查
			 *
			 * @param    now 当前时间(单位us)
			 */
			void checkTimeout(int64_t now);

		private:
			IPacketSpliter * m_spliter;      // 数据包解析器
			IPacketHandler  *m_serverAdapter; // 服务器适配器
	};
}
#endif /*__NET_TCPACCEPTOR_H__*/
