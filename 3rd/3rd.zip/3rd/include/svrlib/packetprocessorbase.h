/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __H_PACKETPROCESSORBASE_H__
#define __H_PACKETPROCESSORBASE_H__
#include "net.h"
#include "TypesDef.h"
#include <vector>

namespace net
{
	class PacketProcessorBase
	{
		private :
			PacketQueue						 m_rcvPacketVec;
			PacketQueue						 m_tmpRcvPacketVec;	
			Mutex							 m_packMutex;		//包向量的锁
		public :
			//构造函数
			PacketProcessorBase(){}
			//析构函数
			virtual ~PacketProcessorBase(){}
			//处理协议
			virtual bool processOneBufferMsg(TCPComponent *pConn,const PacketHeader * header,const void * pNull);
			//添加一个包
			void addPacket(ClientPacket * pPacket);
			//处理所有包
			void processAllPacket();
			//断开连接的包来了
			virtual void disConnnectPacketCome(UINT16 svrID) = 0;
	};
}
#endif
