#ifndef __H_CCOUNTMGR_H__
#define __H_CCOUNTMGR_H__

#include "TypesDef.h"
#include <map>

enum
{
	COUNT_REFRESH_TYPE_DAY = 1,		//每天刷新一下值
	COUNT_REFRESH_TYPE_WEEK = 2,	//每周刷新一下值
	COUNT_REFRESH_TYPE_MONTH = 3,	//每月刷新一下值
};

struct stCountInfo
{
	UINT16  m_id;					//对应的枚举类型
	UINT8   m_refreshType;			//刷新类型
	UINT32  m_value;				//真实值
	UINT32  m_lastRefreshTime;		//上次刷新时间

	stCountInfo()
	{
		m_id  = 0;
		m_refreshType = COUNT_REFRESH_TYPE_DAY;
		m_value  = 0;
		m_lastRefreshTime  = 0;
	}
};

class CCountMgr
{
public :
	//构造
	CCountMgr();
	//析构
	virtual ~CCountMgr();
	//保存
	UINT32 save(byte * buf,UINT32 needSpace);
	//加载
	UINT32 load(byte * buf);
	//获得按天刷新的值
	UINT32 getDayRefreshValue(UINT32 id);
	//给按天刷新的值增加
	UINT32 addDayRefreshValue(UINT32 id,UINT32 value);
	//获得按月刷新的值
	UINT32 getMonthRefreshValue(UINT32 id);
	//给按月刷新的值增加
	UINT32 addMonthRefreshValue(UINT32 id,UINT32 value);
	//获得周刷新的值
	UINT32 getWeekRefreshValue(UINT32 id);
	//给按周刷新的值增加
	UINT32 addWeekRefreshValue(UINT32 id,UINT32 value);
	//重置
	void   resetValue(UINT32 id);
	//重置后的回调
	virtual void  resetValueCB(UINT32 id){}
protected:
	//获得某个类型的数值
	UINT32 getValue(UINT16 id,UINT8 refreshType);
	//给某个类型增加值
	UINT32 addValue(UINT16 id,UINT8 refreshType,UINT32 value);
	//获得当前时间
	virtual UINT32 	curTime() = 0;
	//检查是否可以刷新
	void checkRefresh(stCountInfo & info);
private :
	typedef std::map<UINT16,stCountInfo>::iterator  CCount_IT;
	std::map<UINT16,stCountInfo>  m_countMap;
};

#endif
