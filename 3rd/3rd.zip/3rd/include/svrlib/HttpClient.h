#ifndef __CCHTTPREQUEST_H__
#define __CCHTTPREQUEST_H__

#include "TypesDef.h"
#include "HttpRequest.h"
#include "HttpResponse.h"
#include "Singleton.h"
#include "Thread.h"
#include "ThreadMutex.h"
#include <queue>

class CHttpClient : public Thread
{
	USE_SINGLETON_NEW(CHttpClient)
public:
	//获得实例
    static CHttpClient & getSingleton()
	{
		return THE_SINGLETON::Instance();
	}
	//销毁实例
    static void destroyMe()
	{
		THE_SINGLETON::destroy();	
	}
    //发送异步http请求
	void asynSend(CHttpRequest* pRequest);
	//同步http请求
	CHttpResponse * synSend(CHttpRequest* pRequest);
    //设置连接超时
	inline void setTimeoutForConnect(INT32 value) { m_timeoutForConnect = value; }
    //获得连接超时
	inline int getTimeoutForConnect() {return m_timeoutForConnect; }
    //设置读取超时
	inline void setTimeoutForRead(INT32 value) { m_timeoutForRead = value; };
    //获得读取超时
	inline int getTimeoutForRead() {return m_timeoutForRead; };
	//线程执行
	virtual void run();
	//初始化
    bool init(void);
	//处理http响应
    void processResponse(UINT32 curTime);
	//析构函数
    virtual ~CHttpClient();
private:
	//构造函数
    CHttpClient();
private:
	//连接超时
    INT32 m_timeoutForConnect;
	//读取超时
    INT32 m_timeoutForRead;
	//请求队列
	Mutex m_requestQueueMutex;
	//相应队列
	Mutex m_responseQueueMutex;
	//休眠锁
	Mutex m_sleepMutex;
	//休眠条件
	Cond  m_sleepCondition;
	//请求队列
	std::queue<CHttpRequest *> m_requestQueue;
	//响应对象
	std::queue<CHttpResponse *> m_responseQueue;
};
#endif //__CHTTPREQUEST_H__
