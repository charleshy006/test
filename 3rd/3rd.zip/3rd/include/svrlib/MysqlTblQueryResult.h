#ifndef __CMYSQLTBLQUERYRESULT_H__
#define __CMYSQLTBLQUERYRESULT_H__
#include <mysql/mysql.h>
#include <assert.h>
#include "TypesDef.h"
#include "TblQueryResult.h"

class CMysqlTblQueryResult : public CTblQueryResult
{
    public:
        CMysqlTblQueryResult(MYSQL_RES *result_, UINT64 rowCount_, UINT32 fieldCount_);

        ~CMysqlTblQueryResult();

    	bool fillData(UINT32 recordLen);
		
		byte * getData() { return m_pData; }

		void resetData() { m_pData = NULL ;}

		void setFieldDef(CTblField * tblFieldDef) { m_tblFieldDef = tblFieldDef; }

		UINT32 cacRecordLen();
    private:
        void endQuery();
        MYSQL_RES * m_result;
		byte * m_pData;
		CTblField * m_tblFieldDef;			//该内存如果是new出来的,本类不负责释放
};
#endif
