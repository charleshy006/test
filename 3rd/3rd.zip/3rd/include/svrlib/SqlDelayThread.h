#ifndef __SQLDELAYTHREAD_H__
#define __SQLDELAYTHREAD_H__

#include "Thread.h"
#include "TypesDef.h"
#include <queue>

class CDatabase;
class CSqlOperation;

class CSqlDelayThread : public Thread
{
	public :
    	typedef std::queue<CSqlOperation *> SqlQueue;
    private:
        SqlQueue m_sqlQueue;     
		SqlQueue m_sqlQueueTmp;
		SqlQueue m_cbQueue;
		SqlQueue m_cbQueueTmp;
        CDatabase* m_dbEngine;  
		Mutex  m_sqlQueueMutex;
		Mutex  m_cbQueueMutex;
        volatile bool m_running;
	private:
        CSqlDelayThread();
    public:
        CSqlDelayThread(CDatabase* db);
		virtual ~CSqlDelayThread();
        inline void delay(CSqlOperation* sql)
		{ 
			m_sqlQueueMutex.lock();
			m_sqlQueue.push(sql);
			m_sqlQueueMutex.unlock();
		}
		inline UINT32 sqlNum() {  return m_sqlQueue.size() ;}
        virtual void stop();                                
        virtual void run();
		void terminate();
		void processAllCB();
};

extern CSqlDelayThread * g_delaySqlThread;

#endif           
