#ifndef __ELEMENTMANAGER_H__
#define __ELEMENTMANAGER_H__

#include <ext/hash_map>
#include "TypesDef.h"
#include "Element.h"
#include "CommonMicro.h"
#include "UtilFunction.h"

//Element管理器接口，用户应该根据不同的使用情况继承它
class ElementMgr 
{
protected :
	typedef __gnu_cxx::hash_multimap<UINT32,Element *, my_hash<UINT64>, my_key_equal<UINT64> >	TIDMap;
	typedef __gnu_cxx::hash_map<std::string,Element *, my_hash<std::string> >	TNameMap;
	typedef __gnu_cxx::hash_map<UINT64,Element *, my_hash<UINT64>, my_key_equal<UINT64> >	TTempIDMap;
	
	typedef TIDMap::iterator   TIDMap_IT;
	typedef TNameMap::iterator TNameMap_IT;
	typedef TTempIDMap::iterator TTempIDMap_IT;

	TIDMap m_idMap;
	TNameMap m_nameMap;
	TTempIDMap m_tempIDMap;
private :
	bool m_idRepeat;			//id容器是否允许重复
	bool m_needIDMap;			//是否需要ID容器
	bool m_needNameMap;			//是否需要Name容器
	bool m_needTempID;			//是否需要tempID容器
private :
	bool add2IDMap(Element * e);
	bool add2NameMap(Element * e);
	bool add2TempIDMap(Element * e);
	void removeFromIDMap(Element * e);
	void removeFromNameMap(Element * e);
	void removeFromTempID(Element * e);
protected :
	ElementMgr(bool idRepeat,bool needIDMap,bool needNameMap,bool needTempID);
	virtual ~ElementMgr();
	//根据ID获得Element
	Element * getElementByID(UINT32 id);
	//根据名字获得Element
	Element * getElementByName(char* name);
	//根据临时ID获得Element
	Element * getElementByTempID(UINT64 tempID);
	//元素个数
	inline UINT32 size() const 
	{
		return m_idMap.size(); 
	}
	//是否为空
	inline bool  empty() const
	{
		return m_idMap.empty();
	}
	//增加元素到容器
	bool addElement(Element* e);
	//从容器中删除元素
	void removeElement(Element* e);
	//清空容器
	void clear();

	template <typename T>
	inline bool execEveryElement(execElement<T>& eee)
	{
		for (TIDMap_IT it = m_idMap.begin(); it != m_idMap.end(); ++it) {
			if (!eee.exec((T *)it->second)) {
				return false;
			}
		}
		return true;
	}
};

#endif
