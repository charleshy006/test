#ifndef __H_CALLBACK_H__
#define __H_CALLBACK_H__
#include "TypesDef.h"
#include <string>

namespace Athena
{
    template <class Class, typename ParamType1 = void, typename ParamType2 = void, typename ParamType3 = void, typename ParamType4 = void >
    class _Callback
    {
        protected:
            typedef void (Class::*Method)(ParamType1, ParamType2, ParamType3, ParamType4);
            Class *m_object;
            Method m_method;
            ParamType1 m_param1;
            ParamType2 m_param2;
            ParamType3 m_param3;
            ParamType4 m_param4;
            void _execute() 
			{ 
				(m_object->*m_method)(m_param1, m_param2, m_param3, m_param4);
			}
        public:
            _Callback(Class *object, Method method, ParamType1 param1, ParamType2 param2, ParamType3 param3, ParamType4 param4)
                : m_object(object), m_method(method), m_param1(param1), m_param2(param2), m_param3(param3), m_param4(param4) {}
            _Callback(_Callback < Class, ParamType1, ParamType2, ParamType3, ParamType4> const& cb)
                : m_object(cb.m_object), m_method(cb.m_method), m_param1(cb.m_param1), m_param2(cb.m_param2), m_param3(cb.m_param3), m_param4(cb.m_param4) {}
    };

    template < class Class, typename ParamType1, typename ParamType2, typename ParamType3 >
    class _Callback < Class, ParamType1, ParamType2, ParamType3 >
    {
        protected:
            typedef void (Class::*Method)(ParamType1, ParamType2, ParamType3);
            Class *m_object;
            Method m_method;
            ParamType1 m_param1;
            ParamType2 m_param2;
            ParamType3 m_param3;
            void _execute()
			{ 
				(m_object->*m_method)(m_param1, m_param2, m_param3);
			}
        public:
            _Callback(Class *object, Method method, ParamType1 param1, ParamType2 param2, ParamType3 param3)
                : m_object(object), m_method(method), m_param1(param1), m_param2(param2),m_param3(param3) {}
            _Callback(_Callback < Class, ParamType1, ParamType2, ParamType3 > const& cb)
                : m_object(cb.m_object), m_method(cb.m_method), m_param1(cb.m_param1), m_param2(cb.m_param2), m_param3(cb.m_param3) {}
    };

    template < class Class, typename ParamType1, typename ParamType2 >
    class _Callback < Class, ParamType1, ParamType2 >
    {
        protected:
            typedef void (Class::*Method)(ParamType1, ParamType2);
            Class *m_object;
            Method m_method;
            ParamType1 m_param1;
            ParamType2 m_param2;
            void _execute()
			{ 
				(m_object->*m_method)(m_param1, m_param2);
			}
        public:
            _Callback(Class *object, Method method, ParamType1 param1, ParamType2 param2)
                : m_object(object), m_method(method), m_param1(param1), m_param2(param2) {}
            _Callback(_Callback < Class, ParamType1, ParamType2 > const& cb)
                : m_object(cb.m_object), m_method(cb.m_method), m_param1(cb.m_param1), m_param2(cb.m_param2) {}
    };

    template < class Class, typename ParamType1 >
    class _Callback < Class, ParamType1 >
    {
        protected:
            typedef void (Class::*Method)(ParamType1);
            Class *m_object;
            Method m_method;
            ParamType1 m_param1;
            void _execute() 
			{ 
				(m_object->*m_method)(m_param1);
			}
        public:
            _Callback(Class *object, Method method, ParamType1 param1)
                : m_object(object), m_method(method), m_param1(param1) {}
            _Callback(_Callback < Class, ParamType1 > const& cb)
                : m_object(cb.m_object), m_method(cb.m_method), m_param1(cb.m_param1) {}
    };

    template < class Class >
    class _Callback < Class >
    {
        protected:
            typedef void (Class::*Method)();
            Class *m_object;
            Method m_method;
            void _execute() 
			{
				(m_object->*m_method)();
			}
        public:
            _Callback(Class *object, Method method)
                : m_object(object), m_method(method) {}
            _Callback(_Callback < Class > const& cb)
                : m_object(cb.m_object), m_method(cb.m_method) {}
    };
}

namespace Athena
{
    class ICallback
    {
        public:
            virtual void execute() = 0;
            virtual ~ICallback() {}
    };

    template < class CB >
    class _ICallback : public CB, public ICallback
    {
        public:
            _ICallback(CB const& cb) : CB(cb) {}
            void execute() { CB::_execute(); }
    };

    template < class Class, typename ParamType1 = void, typename ParamType2 = void, typename ParamType3 = void, typename ParamType4 = void >
    class Callback : 
        public _ICallback< _Callback < Class, ParamType1, ParamType2, ParamType3, ParamType4 > >
    {
        private:
            typedef _Callback < Class, ParamType1, ParamType2, ParamType3, ParamType4 > C4;
        public:
            Callback(Class *object, typename C4::Method method, ParamType1 param1, ParamType2 param2, ParamType3 param3, ParamType4 param4)
                : _ICallback< C4 >(C4(object, method, param1, param2, param3, param4)) {}
    };

    template < class Class, typename ParamType1, typename ParamType2, typename ParamType3 >
    class Callback < Class, ParamType1, ParamType2, ParamType3 > : 
        public _ICallback< _Callback < Class, ParamType1, ParamType2, ParamType3 > >
    {
        private:
            typedef _Callback < Class, ParamType1, ParamType2, ParamType3 > C3;
        public:
            Callback(Class *object, typename C3::Method method, ParamType1 param1, ParamType2 param2, ParamType3 param3)
                : _ICallback< C3 >(C3(object, method, param1, param2, param3)) {}
    };

    template < class Class, typename ParamType1, typename ParamType2 >
    class Callback < Class, ParamType1, ParamType2 > : 
        public _ICallback< _Callback < Class, ParamType1, ParamType2 > >
    {
        private:
            typedef _Callback < Class, ParamType1, ParamType2 > C2;
        public:
            Callback(Class *object, typename C2::Method method, ParamType1 param1, ParamType2 param2)
                : _ICallback< C2 >(C2(object, method, param1, param2)) {}
    };

    template < class Class, typename ParamType1 >
    class Callback < Class, ParamType1 > : 
        public _ICallback< _Callback < Class, ParamType1 > >
    {
        private:
            typedef _Callback < Class, ParamType1 > C1;
        public:
            Callback(Class *object, typename C1::Method method, ParamType1 param1)
                : _ICallback< C1 >(C1(object, method, param1)) {}
    };

    template < class Class >
    class Callback < Class > : public _ICallback< _Callback < Class > >
    {
        private:
            typedef _Callback < Class > C0;
        public:
            Callback(Class *object, typename C0::Method method)
                : _ICallback< C0 >(C0(object, method)) {}
    };
}

class CTblQueryResult;

namespace Athena
{
    class IQueryCallback
    {
        public:
            virtual void execute() = 0;
            virtual ~IQueryCallback() {}
            virtual void setResult(CTblQueryResult* result) = 0;
            virtual CTblQueryResult * getResult() = 0;
    };

    template < class CB >
    class _IQueryCallback : public CB, public IQueryCallback
    {
        public:
            _IQueryCallback(CB const& cb) : CB(cb) {}
            void execute() { CB::_execute(); }
            void setResult(CTblQueryResult* result) { CB::m_param1 = result; }
            CTblQueryResult* getResult() { return CB::m_param1; }
    };

    template < class Class, typename ParamType1 = void, typename ParamType2 = void, typename ParamType3 = void >
    class QueryCallback : 
        public _IQueryCallback< _Callback < Class, CTblQueryResult*, ParamType1, ParamType2, ParamType3 > >
    {
        private:
            typedef _Callback < Class, CTblQueryResult*, ParamType1, ParamType2, ParamType3 > QC3;
        public:
            QueryCallback(Class *object, typename QC3::Method method, CTblQueryResult * result, ParamType1 param1, ParamType2 param2, ParamType3 param3)
                : _IQueryCallback< QC3 >(QC3(object, method, result, param1, param2, param3)) {}
    };

    template < class Class, typename ParamType1, typename ParamType2 >
    class QueryCallback < Class, ParamType1, ParamType2 > : 
        public _IQueryCallback< _Callback < Class, CTblQueryResult*, ParamType1, ParamType2 > >
    {
        private:
            typedef _Callback < Class, CTblQueryResult*, ParamType1, ParamType2 > QC2;
        public:
            QueryCallback(Class *object, typename QC2::Method method, CTblQueryResult* result, ParamType1 param1, ParamType2 param2)
                : _IQueryCallback< QC2 >(QC2(object, method, result, param1, param2)) {}
    };

    template < class Class, typename ParamType1 >
    class QueryCallback < Class, ParamType1 > : 
        public _IQueryCallback< _Callback < Class, CTblQueryResult*, ParamType1 > >
    {
        private:
            typedef _Callback < Class, CTblQueryResult*, ParamType1 > QC1;
        public:
            QueryCallback(Class *object, typename QC1::Method method, CTblQueryResult* result, ParamType1 param1)
                : _IQueryCallback< QC1 >(QC1(object, method, result, param1)) {}
    };

    template < class Class >
    class QueryCallback < Class > : public _IQueryCallback< _Callback < Class, CTblQueryResult* > >
    {
        private:
            typedef _Callback < Class, CTblQueryResult* > QC0;
        public:
            QueryCallback(Class *object, typename QC0::Method method, CTblQueryResult* result)
                : _IQueryCallback< QC0 >(QC0(object, method, result)) {}
    };
}

namespace Athena
{
    class IRedisQueryCallback
    {
        public:
            virtual void execute() = 0;
            virtual ~IRedisQueryCallback() {}
            virtual void setResult(std::string * value ) = 0;
            virtual std::string * getResult() = 0;
    };

    template < class CB >
    class _IRedisQueryCallback : public CB, public IRedisQueryCallback
    {
        public:
            _IRedisQueryCallback(CB const& cb) : CB(cb) {}
            void execute() { CB::_execute(); }
            void setResult(std::string * result) { CB::m_param1 = result; }
			std::string * getResult() { return CB::m_param1; }
    };

    template < class Class, typename ParamType1 = void, typename ParamType2 = void, typename ParamType3 = void >
    class RedisQueryCallback : public _IRedisQueryCallback< _Callback< Class, std::string*, ParamType1, ParamType2, ParamType3>  >
    {
        private:
            typedef _Callback < Class,std::string *, ParamType1, ParamType2, ParamType3 > QC3;
        public:
            RedisQueryCallback(Class *object, typename QC3::Method method, std::string * result, ParamType1 param1, ParamType2 param2, ParamType3 param3)
                : _IRedisQueryCallback< QC3 >(QC3(object, method, result, param1, param2, param3)) {}
    };
	
	template < class Class, typename ParamType1, typename ParamType2 >
    class RedisQueryCallback<Class,ParamType1,ParamType2> : 
        public _IRedisQueryCallback< _Callback < Class, std::string*, ParamType1, ParamType2 > >
    {
        private:
            typedef _Callback < Class,std::string*, ParamType1, ParamType2 > QC3;
        public:
            RedisQueryCallback(Class *object, typename QC3::Method method, std::string * result, ParamType1 param1, ParamType2 param2)
                : _IRedisQueryCallback< QC3 >(QC3(object, method, result, param1, param2)) {}
    };
	
	template < class Class, typename ParamType1 >
    class RedisQueryCallback<Class ,ParamType1> : 
        public _IRedisQueryCallback< _Callback < Class, std::string*, ParamType1 > >
    {
        private:
            typedef _Callback < Class,std::string *, ParamType1 > QC3;
        public:
            RedisQueryCallback(Class *object, typename QC3::Method method, std::string * result, ParamType1 param1)
                : _IRedisQueryCallback< QC3 >(QC3(object, method, result, param1)) {}
    };

	template < class Class>
    class RedisQueryCallback<Class> : 
        public _IRedisQueryCallback< _Callback < Class, std::string * > >
    {
        private:
            typedef _Callback < Class,std::string * > QC3;
        public:
            RedisQueryCallback(Class *object, typename QC3::Method method, std::string * result)
                : _IRedisQueryCallback< QC3 >(QC3(object, method, result)) {}
    };
}

namespace Athena
{
	class ICUDSqlCallBack
	{
		public :
			virtual void execute() = 0;
			ICUDSqlCallBack() {}
			virtual ~ICUDSqlCallBack() {}
			virtual void setOpResult(bool v) = 0;
			virtual bool getOpResult() = 0;
			virtual void setAutoIncID(UINT64 v) = 0;
			virtual UINT64 getAutoIncID() = 0; 
	};
	
	template <class CB>
	class _ICUDSqlCallBack : public CB, public ICUDSqlCallBack
	{
		public :
			virtual void execute()
			{
				CB::_execute();
			}
			
			_ICUDSqlCallBack(CB  const & cb) : CB(cb){} 

			virtual void setOpResult(bool v)
			{
				CB::m_param1 = v;			
			}

			virtual bool getOpResult()
			{
				return CB::m_param1;
			}

			virtual void setAutoIncID(UINT64 v)
			{
				CB::m_param2 = v;	
			}

			virtual UINT64 getAutoIncID()
			{
				return CB::m_param2;
			}
	};

	template < class Class, typename ParamType1 = void, typename ParamType2 = void >
    class CUDSqlCallBack : 
        public _ICUDSqlCallBack< _Callback < Class, bool,UINT64,ParamType1, ParamType2 > >
    {
        private:
            typedef _Callback < Class, bool,UINT64,ParamType1, ParamType2 > CUDSqlC2;
        public:
            CUDSqlCallBack(Class *object, typename CUDSqlC2::Method method,bool opResult,UINT64 autoID,ParamType1 param1, ParamType2 param2)
                : _ICUDSqlCallBack< CUDSqlC2 >(CUDSqlC2(object, method, opResult,autoID ,param1, param2)) {}
    };
	
	template < class Class, typename ParamType1>
    class CUDSqlCallBack<Class,ParamType1> : 
        public _ICUDSqlCallBack< _Callback < Class, bool,UINT64,ParamType1> >
    {
        private:
            typedef _Callback < Class,bool,UINT64,ParamType1> CUDSqlC1;
        public:
            CUDSqlCallBack(Class *object, typename CUDSqlC1::Method method,bool opResult,UINT64 autoID,ParamType1 param1)
                : _ICUDSqlCallBack< CUDSqlC1 >(CUDSqlC1(object, method, opResult,autoID ,param1)) {}
    };

	template < class Class>
    class CUDSqlCallBack<Class> : 
        public _ICUDSqlCallBack< _Callback < Class, bool,UINT64> >
    {
        private:
            typedef _Callback < Class,bool,UINT64> CUDSqlC;
        public:
            CUDSqlCallBack(Class *object, typename CUDSqlC::Method method,bool opResult,UINT64 autoID)
                : _ICUDSqlCallBack< CUDSqlC >(CUDSqlC(object, method, opResult,autoID)) {}
    };

}

namespace Athena
{
	class ICUDRedisCallBack
	{
		public :
			virtual void execute() = 0;
			ICUDRedisCallBack() {}
			virtual ~ICUDRedisCallBack() {}
			virtual void setOpResult(bool v) = 0;
			virtual bool getOpResult() = 0;
	};
	
	template <class CB>
	class _ICUDRedisCallBack : public CB, public ICUDRedisCallBack
	{
		public :
			virtual void execute()
			{
				CB::_execute();
			}
			
			_ICUDRedisCallBack(CB  const & cb) : CB(cb){} 

			virtual void setOpResult(bool v)
			{
				CB::m_param1 = v;			
			}

			virtual bool getOpResult()
			{
				return CB::m_param1;
			}
	};
	
	template < class Class, typename ParamType1 = void, typename ParamType2 = void ,typename ParamType3 = void>
    class CUDRedisCallBack : 
        public _ICUDRedisCallBack< _Callback < Class,bool,ParamType1, ParamType2,ParamType3 > >
    {
        private:
            typedef _Callback < Class,bool,ParamType1, ParamType2,ParamType3> CUDRedisC2;
        public:
            CUDRedisCallBack(Class *object, typename CUDRedisC2::Method method,bool opResult,ParamType1 param1, ParamType2 param2,ParamType3 param3)
                : _ICUDRedisCallBack< CUDRedisC2 >(CUDRedisC2(object, method, opResult,param1, param2,param3)) {}
    };
	
	template < class Class, typename ParamType1, typename ParamType2>
    class CUDRedisCallBack<Class,ParamType1,ParamType2> : 
        public _ICUDRedisCallBack< _Callback < Class,bool,ParamType1, ParamType2 > >
    {
        private:
            typedef _Callback < Class,bool,ParamType1, ParamType2> CUDRedisC2;
        public:
            CUDRedisCallBack(Class *object, typename CUDRedisC2::Method method,bool opResult,ParamType1 param1, ParamType2 param2)
                : _ICUDRedisCallBack< CUDRedisC2 >(CUDRedisC2(object, method, opResult,param1, param2)) {}
    };
	
	template < class Class, typename ParamType1>
    class CUDRedisCallBack<Class,ParamType1> : 
        public _ICUDRedisCallBack< _Callback < Class,bool,ParamType1 > >
    {
        private:
            typedef _Callback < Class,bool,ParamType1> CUDRedisC2;
        public:
            CUDRedisCallBack(Class *object, typename CUDRedisC2::Method method,bool opResult,ParamType1 param1)
                : _ICUDRedisCallBack< CUDRedisC2 >(CUDRedisC2(object, method, opResult,param1)) {}
    };

	template < class Class>
    class CUDRedisCallBack<Class> : 
        public _ICUDRedisCallBack< _Callback < Class,bool > >
    {
        private:
            typedef _Callback < Class,bool> CUDRedisC2;
        public:
            CUDRedisCallBack(Class *object, typename CUDRedisC2::Method method,bool opResult)
                : _ICUDRedisCallBack< CUDRedisC2 >(CUDRedisC2(object, method, opResult)) {}
    };
}

#endif
