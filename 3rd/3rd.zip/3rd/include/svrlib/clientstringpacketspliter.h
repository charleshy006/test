#ifndef _CLIENT_STRING_PACKET_SPLITER_H_
#define _CLIENT_STRING_PACKET_SPLITER_H_
#include "net.h"

namespace net
{
	class ClientStringPacketSpliter : public IPacketSpliter 
	{
		public:
			/*
			 * 构造函数
			 */
			ClientStringPacketSpliter();

			/*
			 * 构造函数
			 */
			ClientStringPacketSpliter(IPacketFactory *factory);

			/*
			 * 析构函数
			 */
			~ClientStringPacketSpliter();

			/*
			 * 设置包工厂
			 */
			void setPacketFactory(IPacketFactory *factory);

			/*
			 * 设置包头
			 */
			bool getPacketInfo(DataBuffer *input, PacketHeader *header, bool *broken);

			/*
			 * 解码
			 */
			Packet *decode(DataBuffer *input, PacketHeader *header);

			/*
			 * 编码
			 */
			bool encode(Packet *packet, DataBuffer *output);

			/*
			 * 设置协议ID
			 */
			void setProtoHeader(UINT8 modID,UINT8 funID)
			{
				m_modID = modID;
				m_funID = funID;
			}
		private :
			UINT8  m_modID;
			UINT8  m_funID;
	};
}/*_CLIENT_STRING_PACKET_SPLITER_H_*/
#endif
