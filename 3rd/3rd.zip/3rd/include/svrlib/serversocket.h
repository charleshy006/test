/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_SERVERSOCKET_H__
#define __NET_SERVERSOCKET_H__

namespace net
{
	class ServerSocket : public Socket {

		public:
			/*
			 * 构造函数
			 */
			ServerSocket();
			/*
			 * accept一个新的连接
			 *
			 * @return 一个Socket
			 */
			Socket *accept();

			/*
			 * 打开监听
			 *
			 * @return 是否成功
			 */
			bool listen();

		private:
			int m_backLog; // backlog
	};

}

#endif /*__NET_SERVERSOCKET_H__*/
