/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_IOCOMPONENT_H__
#define __NET_IOCOMPONENT_H__

namespace net
{

	class IOComponent 
	{
		friend class CNetConnMgr;
		friend class CWorkerThreadBase;
		friend class CListenThread;
		friend class CNetIOThread;
		friend class CFreeIOComponentThread;
		public:
		enum {
			NET_CONNECTING = 1,
			NET_CONNECTED,
			NET_CLOSED,
			NET_UNCONNECTED
		};

		public:
		/*
		 * 构造函数
		 */
		IOComponent(CNetConnMgr *owner, Socket *socket);
		/*
		 * 析构函数
		 */
		virtual ~IOComponent();

		/*
		 * 初始化
		 *
		 * @return 是否成功
		 */
		virtual bool init(bool isServer = false, IReConnListener  * pReconnListener = NULL) = 0;

		/*
		 * 关闭
		 */
		virtual void close() {}

		/*
		 * 当有数据可写到时被io线程调用
		 *
		 * @return 是否成功, true - 成功, false - 失败。
		 */
		virtual bool handleWriteEvent() = 0;

		/*
		 * 当有数据可读时被io线程调用
		 *
		 * @return 是否成功, true - 成功, false - 失败。
		 */
		virtual bool handleReadEvent() = 0;

		/*
		 * 超时检查
		 *
		 * @param    now 当前时间(单位us)
		 */
		virtual void checkTimeout(int64_t now) = 0;

		/*
		 * 得到socket句柄
		 *
		 * @return Socket
		 */
		Socket *getSocket() {
			return m_socket;
		}

		/*
		 * 设置SocketEvent
		 */
		void setSocketEvent(SocketEvent *socketEvent) {
			m_socketEvent = socketEvent;
		}

		/*
		 * 设置能读写
		 *
		 * @param writeOn 写是否打开
		 */
		void enableWrite(bool writeOn) {
			if (m_socketEvent) {
				m_socketEvent->setEvent(m_socket, true, writeOn);
			}
		}

		/*
		 * 是否连接状态, 包括正在连接
		 */
		bool isConnectState() {
			return (m_state == NET_CONNECTED || m_state == NET_CONNECTING);
		}

		/*
		 * 得到连接状态
		 */
		int getState() {
			return m_state;
		}

		/*
		 * 设置状态
		 */
		void setState(int state) { m_state = state; }

		/*
		 * 设置是否重连
		 */
		void setAutoReconn(bool on) {
			m_autoReconn = on;
		}

		/*
		 * 得到重连标志
		 */
		bool isAutoReconn() {
			return (m_autoReconn && !m_isServer);
		}

		/**
		 * 是否在ioclist中
		 */
		bool isUsed() {
			return m_inUsed;
		}

		/**
		 * 设置是否被用
		 */
		void setUsed(bool b) {
			m_inUsed = b;
		}

		/**
		 * 最近使用
		 */
		int64_t getLastUseTime() {
			return m_lastUseTime;
		}


		/**
		 * owner
		 */
		CNetConnMgr *getOwner();
		
		/*
		 *  设置等待关闭状态
		 */

		void setWaitClose() {  m_waitClose = true ; }

		/*
		 * 获得是否等待关闭
		 */

		bool isWaitClose()  { return m_waitClose  ;}
		protected:
		CNetConnMgr  *m_owner;
		Socket *m_socket;    // 一个Socket的文件句柄
		SocketEvent *m_socketEvent;
		int m_state;         // 连接状态
		bool m_autoReconn;   // 是否重连
		bool m_isServer;     // 是否为服务器端
		bool m_inUsed;       // 是否在用
		int64_t m_lastUseTime;   // 最近使用的系统时间
		bool m_waitClose;	//等待关闭
		private:
		IOComponent *m_prev; // 用于链表
		IOComponent *m_next; // 用于链表
	};
}
#endif /*__NET_IOCOMPONENT_H__*/
