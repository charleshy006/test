#ifndef __CTBLQUERYRESULT_H__
#define __CTBLQUERYRESULT_H__
#include "TblField.h"

class CTblQueryResult
{
    public:
        CTblQueryResult(UINT64 rowCount_, UINT32 fieldCount_)
            :m_ullLengths(NULL),m_ulFieldCount(fieldCount_), m_ullRowCount(rowCount_)
		{
		
		}
        virtual ~CTblQueryResult() {}
        virtual bool fillData(UINT32 recordLen) = 0;
        UINT32 getFieldCount() const { return m_ulFieldCount; }
        UINT64 getRowCount() const { return m_ullRowCount; }
		virtual void setFieldDef(CTblField * tblFieldDef) {}
		virtual byte * getData() = 0;
		virtual void resetData() = 0;
		virtual UINT32 cacRecordLen() = 0;
    protected:
		unsigned long   *m_ullLengths;
        UINT32 	 m_ulFieldCount;
        UINT64   m_ullRowCount;
};
#endif
