/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_ICONNLISTNER_H__
#define __NET_ICONNLISTNER_H__

#ifndef UNUSED
#define UNUSED(v) ((void)(v))
#endif

namespace net
{
	class IConnListner
	{
		public:
			// 构造函数
			IConnListner() {}
			// 析构函数
			virtual ~IConnListner() {}

			/*  
			 * 连接建立后通知
			 */
			virtual void onAddComponent(IOComponent *ioc) = 0;

			/*  
			 * 连接断开后通知
			 */
			virtual void onRemoveComponent(IOComponent *ioc) = 0;
	};
}

#endif /*NET_ICONNLISTNER_H*/
