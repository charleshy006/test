#ifndef __SQLOPERATION_H__
#define __SQLOPERATION_H__
#include "Database.h"
#include "Callback.h"
#include <string>
class CMysqlTblQueryResult;
class CSqlOperation
{ 
	public:  
		CSqlOperation()
		{
			m_dbID = 1;
		}
		virtual void execute(CDatabase *db) = 0; 
		virtual ~CSqlOperation() {}
		void setSql(const std::string & sql)
		{
			m_sql = sql;
		}
		void setLogSql(const std::string & sql)
		{
			m_logSql = sql;
		}
		virtual void processCB() = 0;
		void selectDB(UINT16 dbID) { m_dbID = dbID; }
	protected  :
		UINT16  m_dbID;
		std::string m_sql;
		std::string m_logSql;
};

class CQuerySqlOperation :public CSqlOperation
{
	public :
		CQuerySqlOperation(Athena::IQueryCallback * callback):m_queryRs(NULL),m_callback(callback)
		{}
		~CQuerySqlOperation();
		virtual void execute(CDatabase *db);
		virtual void processCB();
	protected :
		CTblQueryResult  * m_queryRs;
		Athena::IQueryCallback	 * m_callback;
};

class CCUDSqlOperation :public CSqlOperation
{
	public :
		CCUDSqlOperation(Athena::ICUDSqlCallBack * callback) : m_callback(callback)
		{}
		~CCUDSqlOperation();
		virtual void execute(CDatabase *db);
		virtual void processCB();
	protected :
		Athena::ICUDSqlCallBack * m_callback;
};

#endif
