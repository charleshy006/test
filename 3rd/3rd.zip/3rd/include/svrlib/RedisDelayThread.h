#ifndef __REDISDELAYTHREAD_H__
#define __REDISDELAYTHREAD_H__
#include "Thread.h"
#include "TypesDef.h"
#include "RedisOperation.h"
#include <queue>

class xRedisClient;
class CRedisDelayThread : public Thread
{
	public :
    	typedef std::queue<CRedisOperation *> RedisQueue;
    private:
        RedisQueue m_redisOpQueue;     
		RedisQueue m_redisOpQueueTmp;
		RedisQueue m_cbQueue;
		RedisQueue m_cbQueueTmp;
        xRedisClient * m_pDBEngine;  
		Mutex  m_redisOpQueueMutex;
		Mutex  m_cbQueueMutex;
        volatile bool m_running;
	private:
        CRedisDelayThread();  
	public:
        CRedisDelayThread(xRedisClient* pDB);
		virtual ~CRedisDelayThread();
        inline void delay(CRedisOperation * pRedisOp)
		{ 
			m_redisOpQueueMutex.lock();
			m_redisOpQueue.push(pRedisOp);
			m_redisOpQueueMutex.unlock();
		}
		inline UINT32 redisOpNum() {  return m_redisOpQueue.size() ;}
        virtual void stop();                                
        virtual void run();
		void terminate();
		void processAllCB();
};

extern CRedisDelayThread * g_pDelayRedisThread;

#endif           
