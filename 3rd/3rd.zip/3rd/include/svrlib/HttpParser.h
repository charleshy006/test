#ifndef __H_HTTP_PARSER_H__
#define __H_HTTP_PARSER_H__
#include "KVPair.h"

#define HTTP_STATUS_OK "HTTP/1.1 200 OK\r\n"
#define HTTP_STATUS_CONTINUE "HTTP/1.1 100 Continue\r\n"
#define HTTP_STATUS_NOTFOUND "HTTP/1.1 404 Not Found\r\n"
#define HTTP_KEEP_ALIVE "Connection: Keep-Alive\r\nKeep-Alive: timeout=10, max=10\r\n"
#define HTTP_CONN_CLOSE "Connection: close\r\n"
#define HTTP_CONTENT_TYPE "Content-Type: text/html\r\n"
#define HTTP_CONTENT_LENGTH "Content-Length: %d\r\n"


class CHttpParser
{
public :
	enum eHttpMethod
	{
		eNone = 0,
		eGet =  1,
		ePost = 2,
	};
public :
	//构造函数
	CHttpParser();
	//析构函数
	~CHttpParser();
	//获得请求字符串
	const char *getQuery();
	//是否保持连接
	bool isKeepAlive();
	//查找头
	const char *findHeader(const char *name);
	//解析请求数据
	void parseHttpRequest(const char * pData,const UINT32 & cmdLen);
	//处理返回数据
	std::string buildResponse();
    //设置头
	void setHeader(const char *name, const char *value);
    //设置返回状态
	void setStatus(bool status, const char *statusMessage = NULL);
    //设置body
	void setBody(const char *body, int len);
    //保持连接
	void setKeepAlive(bool keepAlive);
	//重置变量
	void reset();
	//获得请求参数的值
	std::string getReqParamVal(const char * pKey);
	//打印所有头参数
	void printAllHeader();	
	//返回请求路径
	std::string getReqPath() {  return m_reqPath ; }
	//返回post数据
	std::string getPostContent() { return m_strPostContent ; }
	//设置post数据
	void setPostContent(std::string & inStr) { m_strPostContent = inStr ;}
	//清空头
	void clearHeader()
	{
		m_headerMap.clear();	
	}
	//设置继续
	void setContinue(bool bContinue)
	{
		m_isContinue = bContinue;
	}
	//转变post内容为kv形式
	void changePostConent2ReqParm();
	//获得请求方法
	int getMethod()
	{
		return m_method;
	}
private:
    bool m_status;                   				// true ---> 200 , false ---> 404
	std::string m_body;              				// 内容 

	std::string m_strHeader;						//未处理过的包头数据
	std::string m_strQuery;							//请求的字符串
	std::string m_strPostContent;					//请求内容
	bool   		m_isKeepAlive;						//是否保持数据
	int			m_method;							//方法 1 : Get
	typedef __gnu_cxx::hash_map<std::string, std::string, my_hash<std::string>, my_key_equal<std::string> > kvpair_hashtype;
	typedef   kvpair_hashtype::iterator  STRING_MAP_ITER;
	std::string 			m_reqPath;				//请求路径
	kvpair_hashtype 		m_headerMap;			//请求头的key <---> value值
	kvpair_hashtype			m_reqParamMap;			//请求参数
	bool		m_isContinue;						//是否继续
};
#endif
