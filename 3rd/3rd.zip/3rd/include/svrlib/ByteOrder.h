#ifndef __H_BASE_BYTEORDER_H__
#define __H_BASE_BYTEORDER_H__
#include "TypesDef.h"
#include <string>

UINT16 endianSwap(UINT16 value);
UINT32 endianSwap(UINT32 value);
float endianSwap(float value);
double endianSwap(double value);
INT16 endianSwap(INT16 value);
INT32 endianSwap(INT32 value);

template<typename T> inline T endianSwap(T value)
{
	size_t size = sizeof(value);
	switch (size)
	{
	case 2:
		return endianSwap2(value);
	case 4:
		return endianSwap4(value);
	case 8:
		return endianSwap8(value);
	default:
		return value;
	}
}
template<typename T> inline T endianSwap2(T value)
{
	char sBuf[2];
	char* temp;
	memset(sBuf, 0, sizeof(sBuf));
	temp = (char*) (&value);
	sBuf[0] = temp[1];
	sBuf[1] = temp[0];
	T *w = (T*) (&sBuf);
	return *w;
}
template<typename T> inline T endianSwap4(T value)
{
	char sBuf[4];
	char* temp;
	memset(sBuf, 0, sizeof(sBuf));
	temp = (char*) (&value);
	sBuf[0] = temp[3];
	sBuf[1] = temp[2];
	sBuf[2] = temp[1];
	sBuf[3] = temp[0];
	T *w = (T*) (&sBuf);
	return *w;
}
template<typename T> inline T endianSwap8(T value)
{
	char sBuf[8];
	char* temp;
	memset(sBuf, 0, sizeof(sBuf));
	temp = (char*) (&value);
	sBuf[0] = temp[7];
	sBuf[1] = temp[6];
	sBuf[2] = temp[5];
	sBuf[3] = temp[4];
	sBuf[4] = temp[3];
	sBuf[5] = temp[2];
	sBuf[6] = temp[1];
	sBuf[7] = temp[0];
	T *w = (T*) (&sBuf);
	return *w;
}

#endif
