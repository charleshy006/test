#ifndef __CDATABASE_H__
#define __CDATABASE_H__
#include <stdarg.h>
#include <string.h>
#include "TypesDef.h"
#include "MysqlConnPool.h"
#define MAX_SQLQUERY_LEN   2048

class CTblQueryResult;

class CDatabase
{
    protected:
		//CDatabase 构造函数
        CDatabase()
		{
			m_lastIncID = 0;			

		};
    public:
		// ~CDatabase 析构函数
        virtual ~CDatabase();
		//初始化数据库
        virtual bool initialize(const char *szInfo);
		// 查询返回结果
        virtual CTblQueryResult* query(const char *szQql,const UINT32 &len,const char * logSql) = 0;
		//作用同上但是可以格式化
        CTblQueryResult* pQuery(const char *szFormat,...);
		//同上，但是可以格式化
        bool pExecute(const char *szFormat_,...);
		//直接执行
        virtual bool directExecute(const char* szSql_,const UINT32 &len,const char * logSql) = 0;
		//开始事务
        virtual bool beginTransaction()        
        {
            return true;
        }
		//提交事务
        virtual bool commitTransaction() 
        {
            return true;
        }
		// 事务回滚
        virtual bool rollbackTransaction() 
        {
            return false;
        }
		//字符转换
        virtual unsigned long escape_string(char *szTo, const char *szFrom, unsigned long length)
		{ 
			strncpy(szTo,szFrom,length);
			return length;
		}
        void escape_string(std::string& str);
		//选择数据库
		void selectDB(UINT16 dbID) { mysqlConnPool.setCurDatabaseID(dbID); }
	public :
		UINT64 m_lastIncID;
};
#endif
