/*
 * (C) 2014 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */

#ifndef __NET_TCPCOMPONENT_H__
#define __NET_TCPCOMPONENT_H__
#include "SvrInfo.h"

namespace net
{
	class TCPComponent : public IOComponent {
		public:
			/**
			 * 构造函数
			 *
			 * @param owner:            网络库对象
			 * @param host:             监听ip地址或hostname
			 * @param port:             监听端口
			 * @param split :         数据包的双向流，用packet创建，解包，组包。
			 * @param serverAdapter:    用在服务器端，处理包时候回调
			 */
			TCPComponent(CNetConnMgr *owner, Socket *socket,
					IPacketSpliter * spliter, IPacketHandler *serverAdapter);

			/*
			 * 析构函数
			 */
			~TCPComponent();

			/*
			 * 初始化
			 *
			 * @return 是否成功
			 */
			bool init(bool isServer = false,IReConnListener  * pReconnListener = NULL);

			/*
			 * 关闭
			 */
			void close();

			/*
			 * 当有数据可写到时被io线程调用
			 *
			 * @return 是否成功, true - 成功, false - 失败。
			 */
			bool handleWriteEvent();

			/*
			 * 当有数据可读时被io线程调用
			 *
			 * @return 是否成功, true - 成功, false - 失败。
			 */
			bool handleReadEvent();

			/*
			 * 得到connection
			 *
			 * @return TCPNetIO
			 */
			TCPNetIO *getTCPNetIO() {
				return m_tcpNetIO;
			}

			/*
			 * 超时检查
			 *
			 * @param    now 当前时间(单位us)
			 */
			void checkTimeout(int64_t now);

			/*
			 * 连接到socket
			 */
			bool socketConnect();

			/*
			 * 发送packet到发送队列
			 *
			 * @param packet: 数据包
			 */
			bool postPacket(Packet *packet);
			
			/*
			 * 等待发送数据
			 *
			 */
			bool waitForSendData();

			/*
			 * 设置服务器的信息
			 */
			void setSvrInfo(SvrInfo & svrInfo) {  m_svrInfo = svrInfo ;}
			
			/*
			 * 获得服务器信息
			 */
			SvrInfo & getSvrInfo() { return m_svrInfo ;}
		private:
			// TCP io
			TCPNetIO * m_tcpNetIO;
			int64_t m_startConnectTime;
			IReConnListener  * m_pReConnListener;
			int64_t  m_closeTime;
			SvrInfo    m_svrInfo;
	};
}
#endif /*__NET_TCPCOMPONENT_H__*/
