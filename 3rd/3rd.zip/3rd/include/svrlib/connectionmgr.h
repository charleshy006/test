/*
 * (C) 2013 shentan Inc.
 *
 * Authors:
 *	  hedazhi2005@163.com
 */



#ifndef __H_CONNECTIONMGR_H__
#define __H_CONNECTIONMGR_H__
#include "SvrInfo.h"
#include "net.h"
#include <set>

namespace net
{
	class ConnectionMgr : public IConnListner ,public PacketSender
	{
		public :
			//构造函数 
			ConnectionMgr()
			{}
			//析构函数
			virtual ~ConnectionMgr(){}
			//连接来了通知
			void onAddComponent(IOComponent *ioc) { addComponent((TCPComponent *)ioc);}
			//连接端口通知
			void onRemoveComponent(IOComponent *ioc) { delComponent((TCPComponent *)ioc); }
			//添加一个连接 
			void addComponent(TCPComponent * pIoc);
			//删除一个连接
			void delComponent(TCPComponent * pIoc);
			//根据ID发送 
			template <class T>
			bool broadcastByID(UINT16 svrID,const T & cmd);
			//根据类型发送
			template <class T>
			bool broadcastByType(UINT8 type,const T & cmd);
			//给所有连接发送消息
			template <class T>
			bool broadcast2All(const T & cmd);
			//给某个component发送协议
			template <class T>
			bool broadcastByComponent(TCPComponent * pComm,const char *pStr,const UINT32 & size);
			//验证连接
			bool verifyComponent(TCPComponent * pComm,SvrInfo & svrInfo);
		private :
			Mutex       m_connMutex;
			std::map<UINT16,TCPComponent *> m_tcpComponentMap;     //<serverID,TCPComponent *>
			std::set<TCPComponent *>  m_tmpComponentSet;
	};

	template <class T>
		bool ConnectionMgr::broadcastByID(UINT16 svrID,const T & cmd)
		{
			MutexGuard guard(m_connMutex);
			std::map<UINT16,TCPComponent * >::iterator it = m_tcpComponentMap.find(svrID);
			if (it != m_tcpComponentMap.end()){
				std::string retStr;
				cmd.SerializeToString(&retStr);
				return sendClientProto(it->second,cmd.ModID,cmd.FunID,retStr.c_str(),retStr.size());
			}
			return false;
		}

	template <class T>
		bool ConnectionMgr::broadcastByType(UINT8 type,const T & cmd)
		{
			MutexGuard guard(m_connMutex);
			std::map<UINT16,TCPComponent *>::iterator it = m_tcpComponentMap.begin();
			for (;it != m_tcpComponentMap.end() ; ++it){
				SvrInfo svrInfo = it->second->getSvrInfo();
				if (type == svrInfo.m_svrType) {
					std::string retStr;
					cmd.SerializeToString(&retStr);
					sendClientProto(it->second,cmd.ModID,cmd.FunID,retStr.c_str(),retStr.size());
				}
			}
			return true;	
		}

	template <class T>
		bool ConnectionMgr::broadcast2All(const T & cmd)
		{
			MutexGuard guard(m_connMutex);
			std::map<UINT16,TCPComponent *>::iterator it = m_tcpComponentMap.begin();
			for (;it != m_tcpComponentMap.end() ; ++it){
				std::string retStr;
				cmd.SerializeToString(&retStr);
				sendClientProto(it->second,cmd.ModID,cmd.FunID,retStr.c_str(),retStr.size());
			}
			return true;
		}

	template <class T>
		bool ConnectionMgr::broadcastByComponent(TCPComponent * pComm,const char *pStr,const UINT32 & size)
		{
			MutexGuard guard(m_connMutex);
			std::set<TCPComponent *>::iterator it =  m_tmpComponentSet.begin();
			for (;it != m_tmpComponentSet.end() ; ++it){
				if (pComm == *it) {
					return sendClientProto(pComm,0,0,pStr,size);
				}	
			}
			return false;
		}
};
#endif
